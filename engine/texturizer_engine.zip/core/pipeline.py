"""管線總成:七個階段依序跑完,回傳 HRS 文字與報告。

守則(硬規格,測試會逐條驗):
1. 角度值永不修改 —— 本程式只寫時間/Acc/FINE-CONT,以及刪冗餘點
2. manual 標記的點不被自動覆寫
3. 飽和不靜默 —— 一律進報告
4. 長 CONT 串警告
5. 行數超限警告
"""
from __future__ import annotations

from dataclasses import dataclass

from .align import align
from .budget import build_budget
from .classify import classify_points
from .codegen import build_timeline, generate
from .config import Config, RobotParams
from .decimate import decimate
from .feasibility import advise
from .io_metrics import Metrics
from .models import Frame, Report
from .texture import apply_texture
from .valleys import detect_valleys


@dataclass
class Result:
    hrs: str
    report: Report
    frames: list[Frame]


def run(
    frames: list[Frame],
    metrics: Metrics,
    cfg: Config | None = None,
    rp: RobotParams | None = None,
    name: str = "DANCE",
) -> Result:
    cfg = cfg or Config()
    rp = rp or RobotParams()
    report = Report()

    align(frames, metrics, report)                       # ①
    valleys = detect_valleys(metrics, cfg)               # ②
    classify_points(frames, valleys, cfg, report)        # ③
    apply_texture(frames, metrics, cfg, report)          # ④
    frames = decimate(frames, cfg, report)               # ⑤
    build_budget(frames, cfg, rp, report)                # ⑥
    for msg in advise(frames, rp, cfg.style.tempo).messages():            # 可行性診斷(只警告,不改資料)
        report.add_warning(msg)
    hrs = generate(frames, rp, report, name=name)        # ⑦

    report.timeline = build_timeline(frames)
    return Result(hrs=hrs, report=report, frames=frames)
