"""⑤ decimate —— 流暢段抽稀,只留形狀所需的最少經過點。

點太密會撞控制器預讀深度與程式行數上限,也放大姿態偵測抖動。
用關節空間的 Douglas–Peucker:偏離直線不到容差的點就是冗餘。
錨點與 WAIT 永不刪除。
"""
from __future__ import annotations

from .config import Config
from .models import AXES, Frame, Report, Role


def decimate(frames: list[Frame], cfg: Config, report: Report) -> list[Frame]:
    if not cfg.decimate.enabled or len(frames) < 3:
        return frames

    keep = [False] * len(frames)
    for i, f in enumerate(frames):
        if f.role in (Role.ANCHOR, Role.WAIT) or f.manual:
            keep[i] = True

    # 對每段「錨點到錨點」之間的經過點各自簡化
    fixed = [i for i, k in enumerate(keep) if k]
    for a, b in zip(fixed, fixed[1:]):
        if b - a > 1:
            _dp(frames, a, b, cfg.decimate.chord_tol_deg, keep)

    out = [f for f, k in zip(frames, keep) if k]
    report.decimated = len(frames) - len(out)
    return out


def _dp(frames: list[Frame], lo: int, hi: int, tol: float, keep: list[bool]) -> None:
    """Douglas–Peucker:找偏離最大的點,超過容差就保留並遞迴兩側。"""
    if hi - lo < 2:
        return
    worst_i, worst_d = -1, 0.0
    for i in range(lo + 1, hi):
        d = _chord_distance(frames[lo], frames[i], frames[hi])
        if d > worst_d:
            worst_i, worst_d = i, d
    if worst_d > tol and worst_i > 0:
        keep[worst_i] = True
        _dp(frames, lo, worst_i, tol, keep)
        _dp(frames, worst_i, hi, tol, keep)


def _chord_distance(a: Frame, p: Frame, b: Frame) -> float:
    """p 到 a→b 直線的距離(六維關節空間,單位 degree)。"""
    ap = [p.angles[x] - a.angles[x] for x in AXES]
    ab = [b.angles[x] - a.angles[x] for x in AXES]
    ab2 = sum(v * v for v in ab)
    if ab2 < 1e-12:
        return max(abs(v) for v in ap)
    t = sum(x * y for x, y in zip(ap, ab)) / ab2
    t = min(1.0, max(0.0, t))
    return sum((x - t * y) ** 2 for x, y in zip(ap, ab)) ** 0.5
