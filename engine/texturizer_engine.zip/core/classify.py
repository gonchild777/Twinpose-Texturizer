"""③ classify_points —— 決定每個取樣點是錨點還是經過點。

密集撒幀之後,關鍵幀不再是句點而是均勻取樣。這步把落在句點附近的
取樣點升級成錨點(要精確對時、要停),其餘留作經過點(流過去)。
"""
from __future__ import annotations

from .config import Config
from .models import Frame, Report, Role, Valley


def classify_points(
    frames: list[Frame], valleys: list[Valley], cfg: Config, report: Report
) -> list[Frame]:
    tol = cfg.anchor.snap_tolerance_s
    used: set[int] = set()

    for v in valleys:
        best_i, best_d = None, tol
        for i, f in enumerate(frames):
            if f.role is Role.WAIT or i in used:
                continue
            d = abs(f.time - v.time)
            if d <= best_d:
                best_i, best_d = i, d
        if best_i is not None:
            frames[best_i].role = Role.ANCHOR
            frames[best_i].metrics["valley_dwell"] = v.dwell
            frames[best_i].metrics["valley_jerk"] = v.jerk_peak
            frames[best_i].metrics["valley_torque"] = v.torque_peak
            used.add(best_i)

    # 首尾必為錨點:程式要有明確起點,結尾要停穩
    for i in (0, len(frames) - 1):
        if frames[i].role is not Role.WAIT:
            frames[i].role = Role.ANCHOR

    # WAIT 會阻斷 CONT 預讀 → 它前一點強制錨點
    for i, f in enumerate(frames):
        if f.role is Role.WAIT and i > 0 and frames[i - 1].role is not Role.WAIT:
            frames[i - 1].role = Role.ANCHOR

    _warn_long_cont_runs(frames, cfg, report)
    return frames


def _warn_long_cont_runs(frames: list[Frame], cfg: Config, report: Report) -> None:
    """連續 CONT 太長 → 時序漂移無處可收,提醒補錨點。"""
    run_start: float | None = None
    for f in frames:
        if f.role is Role.PASS:
            if run_start is None:
                run_start = f.time
        else:
            if run_start is not None and f.time - run_start > cfg.anchor.max_cont_run_s:
                report.add_warning(
                    f"{run_start:.1f}–{f.time:.1f}s 為連續流暢段(逾 "
                    f"{cfg.anchor.max_cont_run_s:.0f}s),時序可能漂移,建議在此區間加入錨點。"
                )
            run_start = None
