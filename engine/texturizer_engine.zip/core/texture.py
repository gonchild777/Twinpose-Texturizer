"""④ texture —— 把指標翻譯成質感參數(FINE 等級 + Acc%)。

- 錨點:停留時間 + jerk 尖度 → FINE=2/1/0;torque 峰 → Acc%
- 經過點:一律 CONT;Acc 取段內 torque 中位

抄的是**相對輪廓**(分佈對映),不是絕對數值 —— 人和手臂體能不同,
硬抄絕對值會整段撞速度上限,而質感本來就住在對比裡。
"""
from __future__ import annotations

import numpy as np

from .config import Config
from .io_metrics import Metrics
from .models import Frame, Report, Role, Smooth


def apply_texture(
    frames: list[Frame], metrics: Metrics, cfg: Config, report: Report
) -> list[Frame]:
    t_lo = metrics.percentile(cfg.acc_map.low_pct, "torque")
    t_hi = metrics.percentile(cfg.acc_map.high_pct, "torque")
    jerk_hi = metrics.percentile(cfg.classify.jerk_percentile, "jerk")

    for i, f in enumerate(frames):
        if f.manual or f.role is Role.WAIT:      # 手動調過的不覆寫
            continue

        if f.role is Role.ANCHOR:
            dwell = f.metrics.get("valley_dwell", 0.0)
            jpk = f.metrics.get("valley_jerk", metrics.peak(f.time, 0.1, "jerk"))
            f.smooth = _fine_level(dwell, jpk, jerk_hi, cfg)
            tpk = f.metrics.get("valley_torque", metrics.peak(f.time, 0.1, "torque"))
        else:
            f.smooth = Smooth.CONT
            tpk = float(np.median(metrics.window(f.time - 0.1, f.time + 0.1, "torque")))

        f.acc = _map_acc(tpk, t_lo, t_hi, cfg)
        # 契約:覆寫鍵 = 原始關鍵幀索引(decimate 之前)—— 與 Web UI 顯示的清單一致
        ov = getattr(cfg.style, "acc_overrides", None)
        if ov:
            v = ov.get(i, ov.get(str(i)))
            if v is not None:
                f.acc = int(v)          # 使用者覆寫;後續 budget 補償自然吃到新 Acc

    report.anchors = sum(1 for f in frames if f.role is Role.ANCHOR)
    report.pass_points = sum(1 for f in frames if f.role is Role.PASS)
    return frames


def _fine_level(dwell: float, jerk_peak: float, jerk_hi: float, cfg: Config) -> Smooth:
    """停得久又急 → 硬定格;停一下 → 輕頓;幾乎沒停 → 最短停頓。"""
    g = max(getattr(cfg.style, "jerk_gain", 1.0), 1e-6)
    if dwell >= cfg.classify.dwell_fine2_s / g and jerk_peak >= jerk_hi / g:
        return Smooth.FINE2                        # jerk_gain>1 → 更容易判成硬定格
    if dwell >= cfg.classify.dwell_fine1_s / g:
        return Smooth.FINE1
    return Smooth.FINE0


def _map_acc(value: float, lo: float, hi: float, cfg: Config) -> int:
    """torque 分佈 → Acc 區間的線性對映,兩端夾住。"""
    span = max(hi - lo, 1e-9)
    ratio = (value - lo) / span
    acc = cfg.acc_map.min + (cfg.acc_map.max - cfg.acc_map.min) * ratio
    g = getattr(cfg.style, "torque_gain", 1.0)
    mid = (cfg.acc_map.min + cfg.acc_map.max) / 2.0
    acc = mid + (acc - mid) * g          # torque_gain:繞中點放大/壓縮力度對比
    return int(round(min(cfg.acc_map.max, max(cfg.acc_map.min, acc))))
