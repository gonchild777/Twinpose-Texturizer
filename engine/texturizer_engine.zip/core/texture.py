"""④ texture —— 把指標翻譯成質感參數(FINE 等級 + Acc%)。

- 錨點:停留時間 + jerk 尖度 → FINE=2/1/0;torque 峰 → Acc%
- 經過點:一律 CONT;Acc 取段內 torque 中位

抄的是**相對輪廓**(分佈對映),不是絕對數值 —— 人和手臂體能不同,
硬抄絕對值會整段撞速度上限,而質感本來就住在對比裡。
"""
from __future__ import annotations

import numpy as np

from .config import Config
from .io_metrics import Metrics
from .models import Frame, Report, Role, Smooth


def apply_texture(
    frames: list[Frame], metrics: Metrics, cfg: Config, report: Report
) -> list[Frame]:
    t_lo = metrics.percentile(cfg.acc_map.low_pct, "torque")
    t_hi = metrics.percentile(cfg.acc_map.high_pct, "torque")
    jerk_hi = metrics.percentile(cfg.classify.jerk_percentile, "jerk")

    for i, f in enumerate(frames):
        if f.manual or f.role is Role.WAIT:      # 手動調過的不覆寫
            continue

        if f.role is Role.ANCHOR:
            dwell = f.metrics.get("valley_dwell", 0.0)
            jpk = f.metrics.get("valley_jerk", metrics.peak(f.time, 0.1, "jerk"))
            f.smooth = _fine_level(dwell, jpk, jerk_hi, cfg)
            tpk = f.metrics.get("valley_torque", metrics.peak(f.time, 0.1, "torque"))
        else:
            f.smooth = Smooth.CONT
            tpk = float(np.median(metrics.window(f.time - 0.1, f.time + 0.1, "torque")))

        f.acc = _map_acc(tpk, t_lo, t_hi, cfg)
        # 契約:覆寫鍵 = 原始關鍵幀索引(decimate 之前)—— 與 Web UI 顯示的清單一致
        ov = getattr(cfg.style, "acc_overrides", None)
        if ov:
            v = ov.get(i, ov.get(str(i)))
            if v is not None:
                f.acc = int(v)          # 使用者覆寫;後續 budget 補償自然吃到新 Acc

    report.anchors = sum(1 for f in frames if f.role is Role.ANCHOR)
    report.pass_points = sum(1 for f in frames if f.role is Role.PASS)
    return frames


def _fine_level(dwell: float, jerk_peak: float, jerk_hi: float, cfg: Config) -> Smooth:
    """停得久又急 → 硬定格;停一下 → 輕頓;幾乎沒停 → 最短停頓。"""
    g = max(getattr(cfg.style, "jerk_gain", 1.0), 1e-6)
    if dwell >= cfg.classify.dwell_fine2_s / g and jerk_peak >= jerk_hi / g:
        return Smooth.FINE2                        # jerk_gain>1 → 更容易判成硬定格
    if dwell >= cfg.classify.dwell_fine1_s / g:
        return Smooth.FINE1
    return Smooth.FINE0


def _map_acc(value: float, lo: float, hi: float, cfg: Config) -> int:
    """torque 分佈 → Acc 區間的線性對映,兩端夾住。"""
    span = max(hi - lo, 1e-9)
    ratio = (value - lo) / span
    acc = cfg.acc_map.min + (cfg.acc_map.max - cfg.acc_map.min) * ratio
    g = getattr(cfg.style, "torque_gain", 1.0)
    mid = (cfg.acc_map.min + cfg.acc_map.max) / 2.0
    acc = mid + (acc - mid) * g          # torque_gain:繞中點放大/壓縮力度對比
    return int(round(min(cfg.acc_map.max, max(cfg.acc_map.min, acc))))


# ---------------------------------------------------------------------------
# 質感漸變(ramp):在時間區間內,從「無質感」(全段 FINE=1 / Acc=100,即
# 0904 對照組的定義)逐漸過渡到完整質感。λ 由時間線性(平滑)上升 0→1:
#   Acc    連續插值:100 → 質感 Acc
#   PASS   依區間內 ω 排名逐一解鎖 CONT:最流暢的段落最先失去停頓
#   ANCHOR λ ≥ 0.5 後採用質感分級(FINE=0/2),之前維持 FINE=1
# 全部在 budget 之前完成,所以時序補償自動跟著混合後的 smooth/acc 走。
# ---------------------------------------------------------------------------
PLAIN_SMOOTH = Smooth.FINE1
PLAIN_ACC = 100


def _lam(t: float, start: float, end: float, mode: str) -> float:
    if end <= start:
        return 1.0 if t >= end else 0.0
    x = min(max((t - start) / (end - start), 0.0), 1.0)
    x = x * x * (3 - 2 * x)                      # smoothstep:頭尾柔、中段快
    return 1.0 - x if mode == "out" else x


def apply_ramp(frames, metrics, cfg: Config) -> None:
    rp = getattr(cfg.style, "ramp", None)
    if not rp:
        return
    start, end, mode = float(rp["start"]), float(rp["end"]), rp.get("mode", "in")
    lam = {id(f): _lam(f.time, start, end, mode) for f in frames}

    # 區間內 PASS 點的流暢度排名(ω 中位數,越高越先轉 CONT)
    inside = [f for f in frames if f.role is Role.PASS and 0.0 < lam[id(f)] < 1.0]
    flow = {}
    if inside:
        vals = [float(np.median(metrics.window(f.time - 0.1, f.time + 0.1, "omega")))
                for f in inside]
        order = sorted(range(len(inside)), key=lambda k: vals[k])
        n = max(len(inside) - 1, 1)
        for rank, k in enumerate(order):
            flow[id(inside[k])] = rank / n        # 0 = 最慢,1 = 最流暢

    for f in frames:
        if f.role is Role.WAIT or f.manual:
            continue
        L = lam[id(f)]
        f.metrics["ramp"] = round(L, 3)
        if L >= 1.0:
            continue                                # 全質感,原樣
        if L <= 0.0:                                # 全無質感
            f.smooth, f.acc = PLAIN_SMOOTH, PLAIN_ACC
            continue
        f.acc = int(round(PLAIN_ACC + L * (f.acc - PLAIN_ACC)))
        if f.role is Role.PASS:
            if not (L > 1.0 - flow.get(id(f), 0.0)):
                f.smooth = PLAIN_SMOOTH             # 尚未解鎖 → 仍停頓
        elif L < 0.5:
            f.smooth = PLAIN_SMOOTH                 # 錨點前半段維持 FINE=1
