"""讀 TwinPose 的動作輸出。

主格式:Export JSON(有絕對影片時間 → 與 CSV 對齊零風險)
備援格式:Code Editor 匯出的 .hrs 文字(只有相對時間,需給起始偏移)
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .models import AXES, Frame, Role

_E6AXIS_RE = re.compile(
    r"E6AXIS\s+(?P<name>P\d+)\s*=\s*\{(?P<body>[^}]*)\}", re.IGNORECASE
)
_TIME_RE = re.compile(r"TIME\s*=\s*(?P<ms>[\d.]+)\s*msec", re.IGNORECASE)
_WAIT_RE = re.compile(r"WAIT\s+SEC\s+(?P<sec>[\d.]+)", re.IGNORECASE)
# 實機 .hrb 用空格分隔(A1 -71.3),舊格式用等號(A1=-71.3) —— 兩者都接受
_AXIS_RE = re.compile(r"(?P<axis>[AJ]\d)\s*[= ]\s*(?P<val>-?[\d.]+)", re.IGNORECASE)


class InputError(ValueError):
    """輸入檔格式問題,訊息直接面向使用者。"""


def _normalise_axis(name: str) -> str:
    """A1..A6 與 J1..J6 都接受,內部統一成 J#。"""
    return "J" + name[1:]


def load_json(path: str | Path) -> list[Frame]:
    """讀 TwinPose Export JSON。"""
    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if isinstance(raw, dict):                    # 容許 {jointsData: [...]} 包裝
        raw = raw.get("jointsData", raw.get("frames", []))
    if not isinstance(raw, list) or len(raw) < 2:
        raise InputError("動作檔至少需要 2 個關鍵幀。")

    frames: list[Frame] = []
    for i, item in enumerate(raw):
        group = str(item.get("group", "default"))
        time = item.get("time")
        if time is None:
            raise InputError(f"第 {i + 1} 筆缺少 time 欄位。")

        if group == "wait":
            frames.append(
                Frame(
                    time=float(time),
                    angles=dict(frames[-1].angles) if frames else {a: 0.0 for a in AXES},
                    group=group,
                    role=Role.WAIT,
                    wait_sec=float(item.get("wait", item.get("wait_sec", 0.5))),
                )
            )
            continue

        angles_raw = item.get("angles") or {}
        angles = {
            _normalise_axis(k): float(v)
            for k, v in angles_raw.items()
            if re.fullmatch(r"[AJ]\d", k, re.IGNORECASE)
        }
        missing = [a for a in AXES if a not in angles]
        if missing:
            raise InputError(f"第 {i + 1} 筆缺少軸 {', '.join(missing)}。")
        frames.append(Frame(time=float(time), angles=angles, group=group))

    frames.sort(key=lambda f: f.time)
    _assert_increasing(frames)
    return frames


def load_hrs(path: str | Path, start_offset: float = 0.0) -> list[Frame]:
    """讀 HRS 文字檔(備援)。

    HRS 只有段落時距,沒有絕對影片時間 —— 以 start_offset 當第一幀時刻累加還原。
    """
    text = Path(path).read_text(encoding="utf-8", errors="ignore")
    frames: list[Frame] = []
    cursor = float(start_offset)
    pending: dict[str, float] | None = None

    for line in text.splitlines():
        line = line.split("'")[0].split(";")[0].strip()   # 去掉註解(' 與 ; 兩種)
        if not line:
            continue

        m = _E6AXIS_RE.search(line)
        if m:
            angles = {
                _normalise_axis(am.group("axis")): float(am.group("val"))
                for am in _AXIS_RE.finditer(m.group("body"))
            }
            missing = [a for a in AXES if a not in angles]
            if missing:
                raise InputError(f"{m.group('name')} 缺少軸 {', '.join(missing)}。")
            pending = angles
            continue

        mw = _WAIT_RE.search(line)
        if mw and frames:
            sec = float(mw.group("sec"))
            frames.append(
                Frame(
                    time=cursor,
                    angles=dict(frames[-1].angles),
                    group="wait",
                    role=Role.WAIT,
                    wait_sec=sec,
                )
            )
            cursor += sec
            continue

        if line.upper().startswith(("PTP", "LIN")) and pending is not None:
            mt = _TIME_RE.search(line)
            if frames:                              # 第一個點不推進時間
                cursor += (float(mt.group("ms")) / 1000.0) if mt else 0.5
            frames.append(Frame(time=cursor, angles=pending))
            pending = None

    if len(frames) < 2:
        raise InputError("HRS 檔中找不到足夠的點位(至少 2 個)。")
    _assert_increasing(frames)
    return frames


def load_motion(path: str | Path, start_offset: float = 0.0) -> list[Frame]:
    """依副檔名自動選擇解析器。"""
    p = Path(path)
    if p.suffix.lower() in (".json",):
        return load_json(p)
    return load_hrs(p, start_offset=start_offset)


def _assert_increasing(frames: list[Frame]) -> None:
    """時間須遞增。

    例外:WAIT 發生在「剛到達的那個點」上,與前一個動作點共用時間戳是正確的,
    因此只要求非遞減即可。
    """
    for a, b in zip(frames, frames[1:]):
        if b.role is Role.WAIT or a.role is Role.WAIT:
            if b.time < a.time:
                raise InputError(f"時間必須遞增,但 {a.time:.3f}s 之後出現 {b.time:.3f}s。")
            continue
        if b.time <= a.time:
            raise InputError(f"時間必須遞增,但 {a.time:.3f}s 之後出現 {b.time:.3f}s。")
