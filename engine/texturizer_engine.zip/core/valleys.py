"""② valleys —— 從能量曲線找動作的自然句點。

一次「發力—到位」之間,ω 會掉到谷底。這些谷底就是舞句的標點符號,
也是關鍵幀該落腳、手臂該對表的位置。
"""
from __future__ import annotations

import numpy as np

from .config import Config
from .io_metrics import Metrics
from .models import Valley


def detect_valleys(metrics: Metrics, cfg: Config) -> list[Valley]:
    """局部極小 + 分位數門檻 + 最短間隔合併。"""
    e = metrics.energy
    thr = metrics.percentile(cfg.valley.sensitivity, "energy")
    omega_low = metrics.percentile(cfg.classify.omega_low_percentile, "omega")
    jerk_hi = metrics.percentile(cfg.classify.jerk_percentile, "jerk")

    raw: list[Valley] = []
    for i in range(1, len(e) - 1):
        if e[i] <= e[i - 1] and e[i] < e[i + 1] and e[i] < thr:
            raw.append(Valley(time=float(metrics.time[i]), energy=float(e[i])))

    merged = _merge_close(raw, cfg.valley.min_gap_s)
    for v in merged:
        v.dwell = _dwell(metrics, v.time, omega_low)
        v.jerk_peak = metrics.peak(v.time, 0.1, "jerk")
        v.torque_peak = metrics.peak(v.time, 0.1, "torque")
    # jerk_hi 供 texture 階段判斷,附在最後一筆會被忽略 —— 改由 texture 自行取
    return merged


def _merge_close(vs: list[Valley], min_gap: float) -> list[Valley]:
    """相鄰太近的谷只留較深的那個。"""
    out: list[Valley] = []
    for v in vs:
        if out and v.time - out[-1].time < min_gap:
            if v.energy < out[-1].energy:
                out[-1] = v
        else:
            out.append(v)
    return out


def _dwell(metrics: Metrics, t: float, omega_low: float) -> float:
    """ω 低於門檻的連續持續時間 —— 判斷「有沒有真的停住」。"""
    idx = int(np.searchsorted(metrics.time, t))
    idx = max(0, min(idx, len(metrics.time) - 1))
    if metrics.omega[idx] >= omega_low:
        return 0.0
    lo = hi = idx
    while lo > 0 and metrics.omega[lo - 1] < omega_low:
        lo -= 1
    while hi < len(metrics.omega) - 1 and metrics.omega[hi + 1] < omega_low:
        hi += 1
    return float(metrics.time[hi] - metrics.time[lo])
