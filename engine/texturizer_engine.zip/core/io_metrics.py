"""讀分析程式輸出的指標 CSV。

規格:time_s, omega_total, energy, torque, jerk
影片秒數、逐幀、已做零相位平滑(由分析端保證)。
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

import numpy as np

REQUIRED = ("time_s", "omega_total", "energy", "torque", "jerk")


class MetricsError(ValueError):
    """CSV 格式問題,訊息直接面向使用者。"""


@dataclass
class Metrics:
    """指標曲線,支援任意時刻取值與區間統計。"""

    time: np.ndarray
    omega: np.ndarray
    energy: np.ndarray
    torque: np.ndarray
    jerk: np.ndarray

    # ---- 取值 ----
    def at(self, t: float, key: str = "energy") -> float:
        """線性內插取單點值。"""
        return float(np.interp(t, self.time, getattr(self, key)))

    def window(self, t0: float, t1: float, key: str = "energy") -> np.ndarray:
        """取 [t0, t1] 區間的取樣;區間過窄時至少回傳一點。"""
        arr = getattr(self, key)
        lo, hi = np.searchsorted(self.time, [min(t0, t1), max(t0, t1)])
        if hi <= lo:
            return np.array([self.at((t0 + t1) / 2, key)])
        return arr[lo:hi]

    def peak(self, t: float, radius: float, key: str) -> float:
        """t ± radius 內的峰值 —— 力矩/急動度都住在峰值裡,不能取平均。"""
        w = self.window(t - radius, t + radius, key)
        return float(w.max()) if w.size else 0.0

    def percentile(self, p: float, key: str = "energy") -> float:
        return float(np.percentile(getattr(self, key), p))

    @property
    def duration(self) -> float:
        return float(self.time[-1] - self.time[0])

    def covers(self, t0: float, t1: float) -> bool:
        return self.time[0] <= t0 + 1e-6 and t1 - 1e-6 <= self.time[-1]


def load_metrics(path: str | Path) -> Metrics:
    rows: list[dict[str, str]] = []
    with Path(path).open(newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames is None:
            raise MetricsError("CSV 沒有標題列。")
        header = {(h or "").strip().lower() for h in reader.fieldnames}
        missing = [c for c in REQUIRED if c not in header]
        if missing:
            raise MetricsError(f"CSV 缺少欄位:{', '.join(missing)}")
        for r in reader:
            rows.append({(k or "").strip().lower(): v for k, v in r.items()})

    if len(rows) < 2:
        raise MetricsError("CSV 至少需要 2 筆資料。")

    def col(name: str) -> np.ndarray:
        try:
            return np.array([float(r[name]) for r in rows], dtype=float)
        except (TypeError, ValueError) as exc:
            raise MetricsError(f"欄位 {name} 含有非數值資料。") from exc

    t = col("time_s")
    if np.any(np.diff(t) <= 0):
        raise MetricsError("time_s 必須嚴格遞增。")

    return Metrics(
        time=t,
        omega=col("omega_total"),
        energy=col("energy"),
        torque=col("torque"),
        jerk=col("jerk"),
    )
