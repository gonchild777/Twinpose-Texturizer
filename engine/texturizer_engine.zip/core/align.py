"""① align —— 以影片秒數把動作幀與指標曲線接起來。

兩邊都用同一個時鐘(影片時間),所以這步是查表內插,不做時間校正。
"""
from __future__ import annotations

from .io_metrics import Metrics
from .models import Frame, Report


def align(frames: list[Frame], metrics: Metrics, report: Report) -> list[Frame]:
    """把每幀時刻的指標值內插進 frame.metrics。"""
    t0, t1 = frames[0].time, frames[-1].time
    if not metrics.covers(t0, t1):
        report.add_warning(
            f"CSV 時間範圍 {metrics.time[0]:.2f}–{metrics.time[-1]:.2f}s "
            f"未涵蓋動作 {t0:.2f}–{t1:.2f}s,超出區間以邊界值處理。"
        )
    for f in frames:
        f.metrics = {
            "omega": metrics.at(f.time, "omega"),
            "energy": metrics.at(f.time, "energy"),
            "torque": metrics.at(f.time, "torque"),
            "jerk": metrics.at(f.time, "jerk"),
        }
    return frames
