"""可行性診斷:用實測的手臂能力,檢查這支舞「跳不跳得動」。

背景(離線 HRSS,AUTO 100% 實測):
  vmax(J1) ≈ 74 deg/s、amax ≈ 309 deg/s²
  → 加速斜坡固定成本 v/a ≈ 0.24s,每段都躲不掉
  → 低於約 0.3s 的段落做不出有意義的位移

因此撒幀間隔太密時,大量段落會被 T_min 夾住,能量對比被壓平。
本模組不修改任何資料(守則 1:角度永不修改),只診斷並給建議:
撒幀間隔、整體變速、或上游振幅縮放三選一。
"""
from __future__ import annotations

from dataclasses import dataclass

from .budget import limiting_axis, t_min
from .models import Frame, Role


@dataclass
class Artifact:
    """疑似上游資料問題(非手臂能力問題)。"""

    kind: str          # "flip" 反向大跳 / "clamp" 數值貼極限
    axis: str
    t0: float
    t1: float
    detail: str


@dataclass
class Advice:
    total: int
    infeasible: int
    ratio: float
    median_needed: float          # 目前段落所需時間的中位數
    median_actual: float          # 目前段落實際給的時間中位數
    suggested_interval: float     # 建議撒幀間隔(秒)
    suggested_amplitude: float    # 或維持間隔、把振幅縮到幾成
    ramp_cost: float              # 加速斜坡固定成本
    artifacts: list = None        # list[Artifact]

    def messages(self) -> list[str]:
        if self.ratio < 0.05:
            return []
        out = [
            f"可行性:{self.infeasible}/{self.total} 段({self.ratio*100:.0f}%)"
            f"超出手臂能力,這些段落的快慢對比會被壓平。"
        ]
        out.append(
            f"原因:每段固定要花 {self.ramp_cost:.2f}s 在加減速上;"
            f"目前段落平均只給 {self.median_actual:.2f}s,但需要 {self.median_needed:.2f}s。"
        )
        out.append(
            f"三選一:(a) 撒幀間隔改為 {self.suggested_interval:.2f}s 以上;"
            f"(b) 整體變速 tempo≈{self.median_needed / max(self.median_actual, 1e-6):.2f};"
            f"(c) 在 TwinPose 端把動作振幅縮到約 {self.suggested_amplitude*100:.0f}%。"
        )
        seen = set()
        for a in self.artifacts or []:
            if a.axis in seen:          # 同一軸只提示一次,避免洗版
                continue
            seen.add(a.axis)
            out.append(f"注意:{a.detail}")
        return out


def _scale_for(delta: list[float], budget: float, rp, acc: int) -> float:
    """數值求解:位移要縮到幾成,才能在 budget 秒內完成。

    不能用單一解析式 —— 大位移受速度限制(時間 ∝ 位移),
    小位移受加速限制(時間 ∝ 位移平方根),兩者關係不同。
    """
    lo, hi = 0.0, 1.0
    if t_min(delta, rp.vmax, rp.amax, 1.0, acc, rp.c, rp.vel_max_pct) <= budget:
        return 1.0
    for _ in range(40):
        mid = (lo + hi) / 2
        scaled = [d * mid for d in delta]
        if t_min(scaled, rp.vmax, rp.amax, 1.0, acc, rp.c) <= budget:
            lo = mid
        else:
            hi = mid
    return lo


def detect_artifacts(frames: list[Frame], rp) -> list["Artifact"]:
    """找出疑似上游資料問題,避免把它們誤判成「手臂太慢」。

    fast_reversal:同一軸連續兩段大幅反向(A→B→A),合計幾乎抵銷。
          這**通常是真實的快速動作**(例如手臂舉起再放下),
          只是必然超出手臂能力;偶爾才是辨識誤差。所以只提示、不斷言,
          請比對影片確認後再決定要放慢還是縮小振幅。
    clamp:同一數值重複出現且為該軸極端值 —— 外插後被關節極限夾住。
    """
    from .models import AXES

    out: list[Artifact] = []
    motion = [f for f in frames if f.role is not Role.WAIT]
    if len(motion) < 3:
        return out

    for ai, axis in enumerate(AXES):
        vals = [f.angles[axis] for f in motion]
        deltas = [b - a for a, b in zip(vals, vals[1:])]
        span = max(vals) - min(vals)
        if span < 1e-6:
            continue
        big = span * 0.55
        for i in range(len(deltas) - 1):
            d1, d2 = deltas[i], deltas[i + 1]
            if abs(d1) > big and abs(d2) > big and d1 * d2 < 0 and abs(d1 + d2) < abs(d1) * 0.5:
                out.append(
                    Artifact(
                        "fast_reversal", axis, motion[i].time, motion[i + 2].time,
                        f"{axis} 在 {motion[i].time:.1f}-{motion[i+2].time:.1f}s 大幅快速來回"
                        f"({vals[i]:.0f}° → {vals[i+1]:.0f}° → {vals[i+2]:.0f}°)。"
                        f"若為真實動作,此處必然超出手臂能力;請比對影片確認。",
                    )
                )
        # clamp:極端值重複
        for target in (max(vals), min(vals)):
            hits = [f.time for f, v in zip(motion, vals) if abs(v - target) < 1e-6]
            if len(hits) >= 3 and abs(target) > span * 0.4:
                out.append(
                    Artifact(
                        "clamp", axis, hits[0], hits[-1],
                        f"{axis} 有 {len(hits)} 次出現同一極端值 {target:.1f}°"
                        f"(t={', '.join(f'{h:.1f}' for h in hits[:4])}),"
                        f"疑似超出對映範圍後被夾住。",
                    )
                )
    return out


def advise(frames: list[Frame], rp, tempo: float = 1.0) -> Advice:
    """比較每段「需要多少時間」與「實際給多少時間」。

    tempo 必須納入:整體變速後段落確實變長,診斷要看變速後的實際值。
    """
    needed: list[float] = []
    actual: list[float] = []
    dists: list[float] = []

    for prev, f in zip(frames, frames[1:]):
        if f.role is Role.WAIT or prev.role is Role.WAIT:
            continue
        delta = f.delta(prev)
        needed.append(t_min(delta, rp.vmax, rp.amax, rp.t_margin, f.acc, rp.c, rp.vel_max_pct))
        actual.append(max((f.time - prev.time) * tempo, 1e-6))
        dists.append(limiting_axis(delta, rp.vmax)[1])

    if not needed:
        return Advice(0, 0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0, [])

    bad = sum(1 for n, a in zip(needed, actual) if n > a * 1.02)
    med_n = sorted(needed)[len(needed) // 2]
    med_a = sorted(actual)[len(actual) // 2]
    ramp = rp.vmax[0] / max(rp.amax[0], 1e-9)

    # 建議振幅:對每段數值求解可行縮放比,取中位數(半數段落可行)
    scales = []
    for prev, f in zip(frames, frames[1:]):
        if f.role is Role.WAIT or prev.role is Role.WAIT:
            continue
        scales.append(
            _scale_for(f.delta(prev), max((f.time - prev.time) * tempo, 1e-6), rp, f.acc)
        )
    scale = sorted(scales)[len(scales) // 2] if scales else 1.0

    return Advice(
        total=len(needed),
        infeasible=bad,
        ratio=bad / len(needed),
        median_needed=med_n,
        median_actual=med_a,
        suggested_interval=round(max(med_n, med_a) * 1.05, 2),
        suggested_amplitude=max(scale, 0.05),
        ramp_cost=ramp,
        artifacts=detect_artifacts(frames, rp),
    )
