"""TwinPose 直出 .hrb 的時序修正(Time Fix)—— 無質感、只動 TIME。

問題(dance0719 實測):TwinPose 匯出 PTP_TIME FINE=1 時把 TIME 寫成關鍵幀間隔,
但 HRSS 每段 FINE=1 實際多 66ms,另有手臂跟不上的快速大動作被拖長。
  直出 208.719s → 扣 66ms 198.531s → 欠時償還 v2 195.276 / v3 193.156 / v4 193.422
  (目標 194.04s;v4 = −0.32%)

演算法(與 v4 完全相同,已鎖回歸測試):
  1. 每行 FINE=1/2 的 TIME 扣 66ms(FINE=0 / CONT 依引擎同一套補償)
  2. 以 K × t_min 估各段物理下限;低於下限的段記入欠時帳本
  3. 欠時由後續寬裕段就近償還(每段最多扣寬裕的 slack_frac,且不短於 min_seg)
  4. 償還量 = gain × 模型欠時(gain 由 dance0719 實測校正,固定)。
  5. 實測回授:trim_s(秒,可正可負)由 next_trim() 依回填的 $T 算出 ——
     正 = 從寬裕段再扣,負 = 平均加回。紅框在 TwinPose 修好(欠時≈0)時一樣有效。

守則:只改 TIME 數字;角度、FINE/CONT、Acc、其他所有行(含 WAIT FOR $DI)原樣保留。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

import yaml

from .budget import apply_trim, limiting_axis, t_min
from .config import PARAMS_DIR, RobotParams

AXIS_RE = re.compile(
    r"^E6AXIS P(\d+)=\{A1 ([-\d.]+),\s*A2 ([-\d.]+),\s*A3 ([-\d.]+),\s*"
    r"A4 ([-\d.]+),\s*A5 ([-\d.]+),\s*A6 ([-\d.]+)\}"
)
TIME_RE = re.compile(r"TIME=(\d+)")


@dataclass
class TimefixCfg:
    k_floor: float = 0.88        # 物理下限 = K × t_min(模型偏保守,dance0719 校正)
    repay_gain: float = 1.0      # 償還量 = gain × 模型欠時(預設值由 yaml 載入)
    slack_frac: float = 0.65     # 每段最多扣掉寬裕時間的比例
    min_seg: float = 0.30        # 償還後每段最短秒數
    recovery: float = 0.72       # 名目償還的實際回收率(v2 實測),割線法初步斜率用

    @classmethod
    def load(cls, model: str = "MEASURED_AUTO100", path: str | Path | None = None) -> "TimefixCfg":
        p = Path(path) if path else PARAMS_DIR / "robot_params.yaml"
        try:
            data = (yaml.safe_load(p.read_text(encoding="utf-8")) or {}).get(model, {})
            return cls(**(data.get("timefix") or {}))
        except Exception:
            return cls()


@dataclass
class TimefixResult:
    hrb: str
    schedule_s: float            # 目標總長(= TwinPose 原 TIME 總和 = 影片排程)
    raw_pred_s: float            # 直出版模型預測
    fixed_pred_s: float          # 修正版模型預測(帳本結清時 = schedule_s)
    model_debt_s: float          # 扣 66ms 後的模型欠時(gain 的基準)
    repaid_s: float              # 名目償還量
    gain: float
    trim_s: float = 0.0          # 實測回授:要再縮短的秒數(負 = 加長)
    trim_applied_s: float = 0.0  # 實際套用(縮短受寬裕時間限制)
    saturated: list = field(default_factory=list)   # [{p, t, time_ms, floor_ms}]
    repaid_segs: list = field(default_factory=list) # [{p, t, from_ms, to_ms}]
    segments: int = 0


def _offset(line: str, acc: int, rp: RobotParams) -> float:
    """實際 − TIME(秒):與 budget 同一套實測補償。"""
    if " CONT " in line:
        return rp.fine_cmd_offset - rp.cont_saving_base * 100.0 / max(acc, 1)
    if "FINE=0" in line:
        return rp.fine_cmd_offset - 0.065          # test4/test6:FINE=0 比 FINE=1 少 ~65ms
    return rp.fine_cmd_offset                       # FINE=1/2:+66ms(TEST11B)


def _parse(lines: list[str]):
    """回傳 [(行號, TIME 秒, 位移, Acc, 行內容, 點號, 累計排程時刻)]"""
    segs, prev, cur, curp, clock = [], None, None, None, 0.0
    for i, ln in enumerate(lines):
        m = AXIS_RE.match(ln.strip())
        if m:
            curp, cur = int(m.group(1)), [float(x) for x in m.groups()[1:]]
            continue
        s = ln.strip()
        if s.startswith("PTP_TIME") and cur is not None and prev is not None:
            t = TIME_RE.search(s)
            if t:
                T = int(t.group(1)) / 1000.0
                clock += T
                acc = int(re.search(r"Acc=(\d+)", s).group(1)) if "Acc=" in s else 100
                segs.append([i, T, [a - b for a, b in zip(cur, prev)], acc, s, curp, clock])
        if s.startswith("PTP") and cur is not None:
            prev = cur
    return segs


def _floor(delta, acc, rp: RobotParams, cfg: TimefixCfg) -> float:
    return t_min(delta, rp.vmax, rp.amax, rp.k_floor, acc, 0.0, rp.time_track_vel_pct)


def _predict(segs, times, rp, cfg) -> float:
    tot = 0.0
    for s, T in zip(segs, times):
        tot += max(T, _floor(s[2], s[3], rp, cfg)) + _offset(s[4], s[3], rp)
    return tot


def json_to_hrb(doc: dict) -> str:
    """TwinPose JSON → 與 TwinPose 直出同格式的 .hrb(PTP_TIME FINE=1, TIME=間隔)。"""
    ks = [k for k in doc.get("jointsData", []) if k.get("group") != "wait"]
    out = [";Version:310", ";[Point&S]", ";[Point&E]", ";[Program&SV2]"]
    for n, k in enumerate(ks):
        a = k["angles"]
        out += [f"; <Pose {n}>",
                "E6AXIS P%d={A1 %s,A2 %s,A3 %s,A4 %s,A5 %s,A6 %s}" % (
                    n, *(a.get(f"J{j}", 0) for j in range(1, 7)))]
        if n == 0:
            out.append(f"PTP P{n} FINE=1 Vel=10% Acc=100%")
        else:
            ms = round((float(k["time"]) - float(ks[n - 1]["time"])) * 1000)
            out.append(f"PTP_TIME P{n} FINE=1 TIME={ms} msec Acc=100% TOOL[0] BASE[0]")
        out.append("")
    out.append(";[Program&E]")
    return "\n".join(out) + "\n"


def fix_timing(hrb_text: str, rp: RobotParams | None = None, cfg: TimefixCfg | None = None,
               gain: float | None = None, timer: bool = False, trim_s: float = 0.0,
               trigger: bool = True) -> TimefixResult:
    rp = rp or RobotParams.load("MEASURED_AUTO100")
    cfg = cfg or TimefixCfg.load()
    g = cfg.repay_gain if gain is None else max(float(gain), 0.0)
    lines = hrb_text.replace("\r\n", "\n").rstrip("\n").split("\n")
    _reject_processed(lines)
    segs = _parse(lines)
    schedule = sum(s[1] for s in segs)
    raw_pred = _predict(segs, [s[1] for s in segs], rp, cfg)

    # ① 開銷補償(FINE=1 扣 66ms;與 v4 相同:整數 ms、下限 50ms)
    times = []
    for s in segs:
        off_ms = round(_offset(s[4], s[3], rp) * 1000)
        times.append(max(round(s[1] * 1000) - off_ms, 50) / 1000.0)

    # ② 欠時帳本:模型欠時 × gain,由後續寬裕段就近償還
    floors = [_floor(s[2], s[3], rp, cfg) for s in segs]
    model_debt = sum(max(0.0, f - T) for f, T in zip(floors, times))
    saturated, repaid_segs, debt, taken = [], [], 0.0, 0.0
    for k, (s, f) in enumerate(zip(segs, floors)):
        T = times[k]
        if f > T:
            debt += (f - T) * g
            ax, _ = limiting_axis(s[2], rp.vmax)
            orig_ms = round(s[1] * 1000)
            need_ms = round(f * 1000) + (orig_ms - round(T * 1000))   # 在 TwinPose 裡要給的最短間隔
            saturated.append({"p": s[5], "t": round(s[6], 3), "from_t": round(s[6] - s[1], 3),
                              "time_ms": round(T * 1000), "floor_ms": round(f * 1000),
                              "orig_ms": orig_ms, "need_orig_ms": need_ms,
                              "axis": f"J{ax + 1}", "delta_deg": round(s[2][ax], 1)})
            continue
        give = min(debt, cfg.slack_frac * (T - f), max(T - cfg.min_seg, 0.0))
        if give > 0:
            repaid_segs.append({"p": s[5], "t": round(s[6], 3),
                                "from_ms": round(T * 1000), "to_ms": round((T - give) * 1000)})
            times[k] = T - give
            debt -= give
            taken += give

    # ③ 實測回授 trim:正 = 從寬裕段按比例扣(不低於物理下限);負 = 按比例加到每個非飽和段
    applied = _apply_trim(times, floors, float(trim_s or 0.0), cfg)

    # ④ 只改 TIME 數字
    for s, T in zip(segs, times):
        lines[s[0]] = TIME_RE.sub(f"TIME={round(T * 1000)}", lines[s[0]], count=1)

    if trigger and not any(l.strip().upper().startswith("WAIT FOR") for l in lines):
        entry = next((i for i, l in enumerate(lines) if l.strip().startswith("PTP ")), None)
        if entry is not None:                      # 與 Texturizer 相同:進場後補錄影觸發行
            lines.insert(entry + 1, "WAIT FOR $DI[8] == TRUE")
    if timer:
        _insert_timer(lines)
    lines.insert(_header_at(lines),
                 f"; Time Fix by TwinPose Texturizer | schedule {schedule:.2f}s | gain {g:.4f} | correction (trim) {float(trim_s or 0):+.3f}s applied {applied:+.3f}s")
    return TimefixResult(
        hrb="\n".join(lines) + "\n", schedule_s=round(schedule, 3),
        trim_s=round(float(trim_s or 0.0), 3), trim_applied_s=round(applied, 3),
        raw_pred_s=round(raw_pred, 2), fixed_pred_s=round(_predict(segs, times, rp, cfg), 2),
        model_debt_s=round(model_debt, 6), repaid_s=round(taken, 3), gain=round(g, 4),
        saturated=saturated, repaid_segs=repaid_segs, segments=len(segs))


def _apply_trim(times, floors, trim, cfg):
    return apply_trim(times, floors, trim, cfg.slack_frac, cfg.min_seg)


def next_trim(history: list[dict], schedule_s: float) -> float:
    """依實測算下一版 trim(秒)。history = [{"trim_s": t, "measured_s": m}, ...] 依時間順序。

    一筆:扣 1 秒 ≈ 實跑少 1 秒。兩筆以上:最近兩筆不同 trim 的割線,
    斜率不合理(雜訊)時退回 −1。不論偏長偏短、有沒有欠時都改得動。
    """
    pts = [h for h in history if h.get("measured_s") is not None]
    if not pts:
        return 0.0
    t1, m1 = float(pts[-1].get("trim_s", 0.0)), float(pts[-1]["measured_s"])
    slope = -1.0
    for h in reversed(pts[:-1]):
        t0, m0 = float(h.get("trim_s", 0.0)), float(h["measured_s"])
        if abs(t1 - t0) > 1e-4:
            sec = (m1 - m0) / (t1 - t0)
            if -3.0 < sec < -0.3:
                slope = sec
            break
    return t1 + (schedule_s - m1) / slope


class AlreadyTimedError(ValueError):
    """輸入已是時序補償過的檔案(Texturizer 匯出或 Time Fix 輸出)。"""


def _reject_processed(lines: list[str]) -> None:
    head = "\n".join(l for l in lines[:12] if l.lstrip().startswith(";"))
    if "textured by" in head:
        raise AlreadyTimedError(
            "This file was exported by Texturizer, so its timing is already compensated "
            "(FINE lines already have 66 ms removed, debt already settled at anchors). "
            "Running Time Fix on it would remove the 66 ms twice. "
            "Use the Texturizer export as is, or load the original TwinPose .hrb here.")
    if "Time Fix by TwinPose Texturizer" in head:
        raise AlreadyTimedError(
            "This file is already a Time Fix output. Load the original TwinPose .hrb "
            "and use Calibrate to make the next version.")


def _header_at(lines: list[str]) -> int:
    for i, ln in enumerate(lines):
        if ln.strip().startswith(";[Program"):
            return i + 1
    return 0


def _insert_timer(lines: list[str]) -> None:
    """$T[1] 從 WAIT FOR $DI 之後(錄影觸發點)開始;沒有則從進場 PTP 之後。"""
    start = next((i for i, l in enumerate(lines) if l.strip().upper().startswith("WAIT FOR")), None)
    if start is None:
        start = next(i for i, l in enumerate(lines) if l.strip().startswith("PTP "))
    lines[start + 1:start + 1] = ["$T[1] = 0", "WAIT SEC 0", "$T_STOP[1] = FALSE"]
    end = max(i for i, l in enumerate(lines) if l.strip().startswith(";[Program&E]"))
    lines[end:end] = ["", "WAIT SEC 0", "$T_STOP[1] = TRUE"]


def next_gain(history: list[dict], schedule_s: float, model_debt_s: float,
              cfg: TimefixCfg | None = None) -> float:
    """依實測修正 gain。history = [{"gain": g, "measured_s": m}, ...](時間順序)。

    一筆:以「名目償還的實際回收率」估斜率 d(實跑)/d(gain) = −debt × recovery。
    兩筆以上:用最近兩筆不同 gain 的割線;斜率異常(≥0)時退回一筆的估法。
    """
    cfg = cfg or TimefixCfg.load()
    pts = [h for h in history if h.get("measured_s")]
    if not pts:
        return cfg.repay_gain
    g1, m1 = float(pts[-1]["gain"]), float(pts[-1]["measured_s"])
    slope = -max(model_debt_s, 1e-6) * cfg.recovery
    for h in reversed(pts[:-1]):
        g0, m0 = float(h["gain"]), float(h["measured_s"])
        if abs(g1 - g0) > 1e-6:
            sec = (m1 - m0) / (g1 - g0)
            if sec < 0:
                slope = sec
            break
    # 線性外插到目標:m1 + slope·(g − g1) = schedule
    return max(g1 + (schedule_s - m1) / slope, 0.0)
