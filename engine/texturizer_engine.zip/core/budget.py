"""⑥ budget —— 時間預算:算出每段的 TIME 或 Vel%,並在錨點吸收漂移。

核心問題:CONT 段沒有 TIME 指令,只能用 Vel% 近似,而 Vel 是整數、
轉角圓滑又會偷時間 —— 漂移必然發生。

解法(學舞者):流段允許自由呼吸,重拍必須踩死。每個錨點是絕對時刻,
進入錨點那段用 PTP_TIME,TIME = 錨點時刻 − 前面 CONT 串的預測耗時。
"""
from __future__ import annotations

import math

from .config import Config
from .models import AXES, Frame, Report, Role


# --------------------------------------------------------------------------
# 單段運動學
# --------------------------------------------------------------------------
def limiting_axis(delta: list[float], vmax: list[float]) -> tuple[int, float]:
    """PTP 六軸同步 → 走最久的那軸決定整段時間。回傳 (軸索引, 位移絕對值)。"""
    ratios = [abs(d) / max(v, 1e-9) for d, v in zip(delta, vmax)]
    i = max(range(len(ratios)), key=lambda k: ratios[k])
    return i, abs(delta[i])


def t_min(
    delta: list[float],
    vmax: list[float],
    amax: list[float],
    margin: float,
    acc_pct: int = 100,
    overhead: float = 0.0,
    vel_max_pct: float = 100.0,
) -> float:
    """該段的物理最短時間(梯形/三角形速度曲線 + 固定開銷),再乘安全係數。

    **Acc 會改變下限**,實測驗證:
      能達到巡航速度時(D >= v^2/a)走梯形:T = D/v + v/a
      達不到時走三角形:T = 2*sqrt(D/a)
    離線量測佐證(J1 位移 127.2 度,overhead=0.07):
      Acc=100 → 模型 2.03s vs 實測 1.975s(+2.7%)
      Acc=10  → 模型 4.13s vs 實測 4.060s(+1.7%)
    """
    i, d = limiting_axis(delta, vmax)
    if d < 1e-9:
        return max(0.05, overhead)
    v = max(vmax[i], 1e-9)
    a = max(amax[i] * acc_pct / 100.0, 1e-9)
    if d >= v * v / a:                       # 追得上巡航速度 → 梯形
        t = d / v + v / a
    else:                                    # 追不上 → 三角形
        t = 2.0 * math.sqrt(d / a)
    t *= 100.0 / max(vel_max_pct, 100.0)     # 超頻天花板(test8:輪廓近乎線性縮放)
    return (t + overhead) * margin


def vel_for_time(delta: list[float], target_s: float, acc_pct: int, rp) -> tuple[int, bool]:
    """由目標時間反解 Vel%(梯形速度模型)。

    T = D/v + v/a  →  v² − aT·v + aD = 0,取物理解(較小根)。
    判別式 < 0 表示這個時間做不到 → 回傳 100% 並標記飽和。
    """
    i, d = limiting_axis(delta, rp.vmax)
    if d < 1e-9:
        return 1, False
    a = max(rp.amax[i] * acc_pct / 100.0, 1e-9)
    # k_od:實機顯示流段/混合軌實際耗時 ≈ 模型 × k_od(transition2 對帳 0.69),
    # 等效把運動學目標放大 1/k_od 再解 —— PTP_TIME 軌不受影響。
    target_s = target_s / max(rp.k_od, 1e-9) if rp.k_od != 1.0 else target_s
    disc = (a * target_s) ** 2 - 4.0 * a * d
    if disc > 0:
        v = (a * target_s - math.sqrt(disc)) / 2.0
        pct = round(v / max(rp.vmax[i], 1e-9) * 100.0)
        if pct <= 100:
            return int(max(1, pct)), False
    # Vel<=100 做不到 → 超頻區(實測韌體收至 vel_max_pct;test8 驗證近乎線性)
    if rp.vel_max_pct > 100:
        v1 = max(rp.vmax[i], 1e-9)
        tk = (d / v1 + v1 / a) * rp.k_od        # s=1 完整運動時間(含實測修正)
        s_need = tk / max(target_s * max(rp.k_od, 1e-9) - rp.c, 1e-9)
        pct = round(100.0 * s_need)
        if pct <= rp.vel_max_pct:
            return int(max(101, pct)), False
        return int(rp.vel_max_pct), True
    return 100, True


def predict_time(
    delta: list[float], vel_pct: int, acc_pct: int, rp, is_cont: bool = False
) -> float:
    """正向模型:吃**量化後**的整數 Vel% 回推實際耗時。

    量化誤差正是漂移來源,所以錨點補償一定要用這個函式,
    不能直接用原本的目標時間累加。

    is_cont:CONT 轉角不減速到零、且會抄內側近路,實測每個轉角
    省下約 7%(test6:同樣 Vel=30% 下 FINE=1 4367ms vs CONT 4056ms)。
    """
    i, d = limiting_axis(delta, rp.vmax)
    if d < 1e-9:
        return rp.c
    if vel_pct <= 100:
        v = max(rp.vmax[i] * vel_pct / 100.0, 1e-9)
        a = max(rp.amax[i] * acc_pct / 100.0, 1e-9)
        t = rp.k * ((d / v) + v / a) * (rp.k_od if is_cont else 1.0) + rp.c
    else:                                       # 超頻:整體輪廓 1/s 縮放(test8)+ k_od 實測修正
        v1 = max(rp.vmax[i], 1e-9)
        a = max(rp.amax[i] * acc_pct / 100.0, 1e-9)
        t = (d / v1 + v1 / a) * rp.k_od * 100.0 / vel_pct + rp.c
    return t * (1.0 - rp.cont_saving) if is_cont else t


# --------------------------------------------------------------------------
# 整條序列
# --------------------------------------------------------------------------
def _single_track(frames, cfg, rp, report) -> None:
    """單軌模式(TEST11 後):全曲 PTP_TIME,逐段時間驅動。

    實測語意(新版 HRSS):FINE 段實際 = TIME+66ms;CONT 段實際 = TIME−238ms
    (圓滑每轉角省 304ms,扣開銷差後淨 238ms)→ 生成時預先補回,逐段準時。
    夾住(低於 175% 物理下限)的欠時記入 drift,由下一個錨點扣抵。
    """
    from .models import Smooth
    tempo = cfg.style.tempo
    drift = 0.0
    for prev, f in zip(frames, frames[1:]):
        if f.role is Role.WAIT or prev.role is Role.WAIT:
            continue
        delta = f.delta(prev)
        target = max((f.time - prev.time) * tempo, 1e-3)
        floor = t_min(delta, rp.vmax, rp.amax, 1.0, f.acc,
                      rp.overhead(f.smooth), rp.time_track_vel_pct)
        if f.smooth is Smooth.CONT:
            # 轉角節省與加速斜坡成正比(實測驗證:55 段聚合誤差 0.9%):
            #   saving = 304ms × (100/Acc)  [test11b 於 Acc=100 量得 304ms]
            saving = rp.cont_saving_base * 100.0 / max(f.acc, 1)
            floor = max(floor - saving, 0.06)
        is_anchor = f.role is Role.ANCHOR
        want = target - (drift if is_anchor else 0.0)
        actual = max(want, floor)
        if actual > want + 1e-6:
            f.saturated = True
            report.saturated_segments.append(
                {"index": frames.index(f), "time": round(f.time, 3),
                 "wanted_ms": int(max(want, 0) * 1000),
                 "clamped_ms": int(actual * 1000)})
        if f.smooth is Smooth.CONT:
            saving = rp.cont_saving_base * 100.0 / max(f.acc, 1)
            off = min(saving, actual - 0.05) - rp.fine_cmd_offset  # 僅防 TIME 翻非正
        else:
            saving = 0.0
            off = -rp.fine_cmd_offset
        f.time_ms = max(int(round((actual + off) * 1000)), 10)
        # 依實際發出的 TIME 估計真實耗時(補償被保險絲夾住的段會跑得比排程快,
        # 產生「負債=盈餘」),一併記入 drift,由後續錨點吐回 —— 總長由構造收斂。
        est = f.time_ms / 1000.0 + rp.fine_cmd_offset - saving
        drift = (est - want) if is_anchor else (drift + est - target)
        f.vel = None
    if drift > 0.05:
        report.add_warning(
            f"單軌:結尾殘留 {drift*1000:.0f}ms 欠時(轉身段物理極限),總長將多出此值。")
    if report.saturated_segments:
        report.add_warning(
            f"{len(report.saturated_segments)} 段已達手臂速度極限,"
            "該處能量對比會被壓縮(可放慢整體 tempo 或減少該段角度變化)。")


def build_budget(frames: list[Frame], cfg: Config, rp, report: Report) -> list[Frame]:
    """填入每幀的 time_ms(錨點)或 vel(經過點),並處理飽和與漂移。

    時間基準:錨點的可用時間 = 距**上一個錨點**的絕對時間差(乘 tempo),
    扣掉中間流段的預測耗時。基準取錯(例如只看前一幀)會讓補償值失真。
    """
    report.timing_estimated = not rp.calibrated
    if getattr(rp, "single_track", False):
        _single_track(frames, cfg, rp, report)
        return frames
    tempo = max(cfg.style.tempo, 1e-3)

    last_anchor_time = frames[0].time     # 上一個錨點的影片時刻
    drift = 0.0                           # 自上一個錨點起,流段的預測累積耗時

    for i, f in enumerate(frames):
        if i == 0 or f.role is Role.WAIT:
            if f.role is Role.WAIT:
                drift += f.wait_sec or 0.0
            continue
        prev = frames[i - 1]
        if prev.role is Role.WAIT:
            prev = frames[i - 2] if i >= 2 else prev

        delta = f.delta(prev)

        if f.role is Role.ANCHOR:
            # ⚠ TEST9C 實測:PTP_TIME 是「額定鎖」——內部速度上限 = Vel100,
            #   吃不到超頻。錨點下限必須用 100% 天花板計算,
            #   否則生成的 TIME 低於可達值,被控制器靜默延長 → 錨點漂移。
            tmin_rated = t_min(delta, rp.vmax, rp.amax, rp.t_margin,
                               f.acc, rp.overhead(f.smooth), rp.time_track_vel_pct)
            budget = (f.time - last_anchor_time) * tempo
            remain = budget - drift

            if remain < tmin_rated - 1e-6 and rp.vel_max_pct > rp.time_track_vel_pct:
                # 混合軌:PTP_TIME 做不到這麼快,但 PTP+FINE+Vel 超頻做得到。
                # 保留 FINE 的停頓質感、犧牲精確對時;
                # 誤差由下一個真錨點吸收(不重設 last_anchor / drift)。
                tmin_od = t_min(delta, rp.vmax, rp.amax, rp.t_margin,
                                f.acc, rp.overhead(f.smooth), rp.vel_max_pct)
                vel, sat = vel_for_time(delta, max(remain, tmin_od), f.acc, rp)
                f.vel = vel
                f.time_ms = None
                if sat or remain < tmin_od:
                    f.saturated = True
                    report.saturated_segments.append(
                        {"index": i, "time": round(f.time, 3),
                         "wanted_ms": int(max(remain, 0) * 1000),
                         "clamped_ms": int(tmin_od * 1000)})
                drift += predict_time(delta, vel, f.acc, rp)
                report.hybrid_anchors = getattr(report, "hybrid_anchors", 0) + 1
                continue

            clamped = max(remain, tmin_rated)
            if clamped > remain + 1e-6:
                f.saturated = True
                report.saturated_segments.append(
                    {
                        "index": i,
                        "time": round(f.time, 3),
                        "wanted_ms": int(max(remain, 0) * 1000),
                        "clamped_ms": int(clamped * 1000),
                    }
                )
            f.time_ms = int(round(clamped * 1000))
            last_anchor_time = f.time
            drift = 0.0
        else:
            tmin = t_min(delta, rp.vmax, rp.amax, rp.t_margin,
                         f.acc, rp.overhead(f.smooth), rp.vel_max_pct)
            target = max((f.time - prev.time) * tempo, 1e-3)
            vel, sat = vel_for_time(delta, max(target, tmin), f.acc, rp)
            f.vel = vel
            if vel > 100:
                report.add_warning(
                    "已使用 Vel>100% 超頻(test8 以純 PTP+FINE 驗證);"
                    "與 CONT 併用尚未實測,首跑請目視確認。")
            if sat or target < tmin:
                f.saturated = True
                report.saturated_segments.append(
                    {
                        "index": i,
                        "time": round(f.time, 3),
                        "wanted_ms": int(target * 1000),
                        "clamped_ms": int(tmin * 1000),
                    }
                )
            drift += predict_time(delta, vel, f.acc, rp, is_cont=True)

    if getattr(report, "hybrid_anchors", 0):
        report.add_warning(
            f"{report.hybrid_anchors} 個錨點改走混合軌(PTP+FINE+Vel 超頻):"
            "PTP_TIME 額定鎖(TEST9C)無法達成該速度;對時誤差由下一個錨點吸收。")
    if report.saturated_segments:
        report.add_warning(
            f"{len(report.saturated_segments)} 段已達手臂速度極限,"
            "該處能量對比會被壓縮(可放慢整體 tempo 或減少該段角度變化)。"
        )
    return frames

