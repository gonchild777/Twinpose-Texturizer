"""⑦ codegen —— 產生最終 HRB 程式(雙軌)。

實機已確認 PTP_TIME 不接受 CONT,所以:
  錨點 → PTP_TIME P# FINE=n TIME=# msec Acc=#%   (精確對時)
  經過點 → PTP P# CONT Vel=#% Acc=#%             (流暢通過)

格式依實機 .hrb 檔:
  - 註解用 ";"(不是 "'")
  - E6AXIS 以**空格**分隔軸名與數值:{A1 -71.3,A2 -47.1}
  - 需有 Version / Point / Program 區段標頭
"""
from __future__ import annotations

from datetime import datetime

from .models import AXES, Frame, Report, Role, Smooth

VERSION = ";Version:310"


def generate(frames: list[Frame], rp, report: Report, name: str = "DANCE") -> str:
    lines: list[str] = [
        VERSION,
        ";[Point&S]",
        ";[Point&E]",
        ";[Program&SV2]",
        f"; {name} | textured by HRS Texturizer",
        f"; robot: {rp.name} | generated: {datetime.now():%Y-%m-%d %H:%M}",
        f"; anchors: {report.anchors}  pass: {report.pass_points}"
        f"  decimated: {report.decimated}",
    ]
    if report.timing_estimated:
        lines.append("; WARNING: timing is ESTIMATED (robot not calibrated)")

    for i, f in enumerate(frames):
        idx = i + 1
        lines.append("")
        if f.role is Role.WAIT:
            lines.append(f"; <Wait {idx}>")
            lines.append(f"WAIT SEC {f.wait_sec:.2f}")
            continue

        role_note = "進場" if i == 0 else ("錨點" if f.role is Role.ANCHOR else "流段")
        flag = " [SAT]" if f.saturated else ""
        lines.append(f"; <Pose {idx}> {role_note} @ {f.time:.2f}s{flag}")
        lines.append(f"E6AXIS P{idx}={_e6axis(f)}")

        if i == 0:
            lines.append(f"PTP P{idx} FINE=1 Vel=10% Acc=50% TOOL[0] BASE[0]")
        elif f.role is Role.ANCHOR:
            if f.time_ms is None and f.vel is not None:
                # 混合軌(TEST9C):PTP_TIME 額定鎖做不到的極快 hit,
                # 改 PTP+FINE+Vel 超頻 —— 保留停頓質感,對時交給下一錨點吸收
                lines.append(
                    f"PTP P{idx} {f.smooth.value} Vel={f.vel}% "
                    f"Acc={f.acc}% TOOL[0] BASE[0]"
                )
            else:
                lines.append(
                    f"PTP_TIME P{idx} {f.smooth.value} TIME={f.time_ms} msec "
                    f"Acc={f.acc}% TOOL[0] BASE[0]"
                )
        else:
            if f.time_ms is not None:
                # 單軌模式:流段也走 PTP_TIME(+CONT),TIME 已含 238ms 圓滑補償
                lines.append(
                    f"PTP_TIME P{idx} {Smooth.CONT.value} TIME={f.time_ms} msec "
                    f"Acc={f.acc}% TOOL[0] BASE[0]"
                )
            else:
                lines.append(
                    f"PTP P{idx} {Smooth.CONT.value} Vel={f.vel}% "
                    f"Acc={f.acc}% TOOL[0] BASE[0]"
                )

    lines.append(";[Program&E]")

    if len(lines) > rp.max_lines:
        report.add_warning(
            f"輸出 {len(lines)} 行,超過上限 {rp.max_lines} 行 —— "
            "請加大 decimate.chord_tol_deg 以減少經過點。"
        )
    # ⚠ 檔尾必須有換行:HRSS 載入器對缺少結尾換行的檔案報
    #   Err01-02-11 "Fix corrupted file"(實機除錯結論,2026-08-11)。
    return "\n".join(lines) + "\n"


def _e6axis(f: Frame) -> str:
    """實機格式:軸名與數值以空格分隔,軸間以逗號分隔,無空格。"""
    body = ",".join(f"A{k[1]} {f.angles[k]:.1f}" for k in AXES)
    return "{" + body + "}"


def build_timeline(frames: list[Frame]) -> list[dict]:
    """給報告/Web UI 用的逐點摘要。"""
    out = []
    for i, f in enumerate(frames):
        out.append(
            {
                "p": i + 1,
                "t": round(f.time, 3),
                "role": f.role.value,
                "smooth": f.smooth.value if f.role is not Role.WAIT else "WAIT",
                "acc": f.acc,
                "time_ms": f.time_ms,
                "vel": f.vel,
                "saturated": f.saturated,
                "manual": f.manual,
            }
        )
    return out
