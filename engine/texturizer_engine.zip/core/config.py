"""設定載入:處理參數(config.yaml)與手臂參數(robot_params.yaml)。

兩者都有內建預設值,沒有檔案也能跑 —— 但手臂參數未校正時
report.timing_estimated = True,輸出會標註「時序為估計值」。
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any

import yaml

PARAMS_DIR = Path(__file__).resolve().parent.parent / "params"


# --------------------------------------------------------------------------
# 處理參數
# --------------------------------------------------------------------------
@dataclass
class ValleyCfg:
    sensitivity: float = 45.0      # 低谷門檻(能量分位數)
    min_gap_s: float = 0.25        # 相鄰低谷最短間隔


@dataclass
class AnchorCfg:
    snap_tolerance_s: float = 0.15  # 取樣點距句點多近算錨點
    max_cont_run_s: float = 8.0     # 連續 CONT 串上限,超過就警告


@dataclass
class ClassifyCfg:
    dwell_fine2_s: float = 0.15
    dwell_fine1_s: float = 0.06
    jerk_percentile: float = 75.0
    omega_low_percentile: float = 15.0   # ω「算停住了」的門檻


@dataclass
class MapCfg:
    low_pct: float = 5.0
    high_pct: float = 95.0
    min: float = 30.0
    max: float = 100.0


@dataclass
class DecimateCfg:
    enabled: bool = True
    chord_tol_deg: float = 1.5


@dataclass
class StyleCfg:
    energy_gain: float = 1.0       # >1 誇張化能量對比
    tempo: float = 1.0
    torque_gain: float = 1.0     # >1 力度對比更強(Acc 分佈更開),<1 更平均
    jerk_gain: float = 1.0       # >1 更容易判成頓(FINE 門檻放寬),<1 更流             # <1 加速、>1 放慢


@dataclass
class Config:
    valley: ValleyCfg = field(default_factory=ValleyCfg)
    anchor: AnchorCfg = field(default_factory=AnchorCfg)
    classify: ClassifyCfg = field(default_factory=ClassifyCfg)
    acc_map: MapCfg = field(default_factory=MapCfg)
    energy_map: MapCfg = field(default_factory=lambda: MapCfg(min=0.0, max=0.0))
    decimate: DecimateCfg = field(default_factory=DecimateCfg)
    style: StyleCfg = field(default_factory=StyleCfg)

    @classmethod
    def load(cls, path: str | Path | None = None) -> "Config":
        if path is None:
            path = PARAMS_DIR / "config.yaml"
        p = Path(path)
        if not p.exists():
            return cls()
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        return cls(
            valley=ValleyCfg(**data.get("valley", {})),
            anchor=AnchorCfg(**data.get("anchor", {})),
            classify=ClassifyCfg(**data.get("classify", {})),
            acc_map=MapCfg(**data.get("acc_map", {})),
            energy_map=MapCfg(**data.get("energy_map", {"min": 0.0, "max": 0.0})),
            decimate=DecimateCfg(**data.get("decimate", {})),
            style=StyleCfg(**data.get("style", {})),
        )

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --------------------------------------------------------------------------
# 手臂參數
# --------------------------------------------------------------------------
@dataclass
class RobotParams:
    """單一機型的運動能力與時序模型。

    vmax/amax 未校正前用規格表理論值;timing_model 由 M0 校正實驗擬合。
    """

    name: str = "GENERIC6"
    vmax: list[float] = field(default_factory=lambda: [180.0] * 6)   # deg/s
    amax: list[float] = field(default_factory=lambda: [720.0] * 6)   # deg/s^2 @Acc=100%
    weights: list[float] = field(default_factory=lambda: [3, 3, 2, 1, 1, 1])
    joint_limits: dict = field(default_factory=dict)   # {"J1": [min, max], ...} deg
    k: float = 1.0                      # 時序模型 T ≈ k·(D/v) + c
    c: float = 0.0                      # 固定開銷(秒),FINE=1/2 的值
    c_fine0: float = 0.0                # FINE=0 的固定開銷(有預讀,較短)
    cont_saving: float = 0.0            # CONT 每個轉角省下的時間比例(圓滑抄近路)
    vel_max_pct: float = 100.0          # Vel 上限;實測韌體收到 200(超頻)
    k_od: float = 1.0                   # 流段/混合軌時間修正(實跑/模型;短位移連續串外插修正)
    time_track_vel_pct: float = 100.0   # PTP_TIME 軌速度天花板;test9c-2 實測 175
    single_track: bool = False          # 全曲 PTP_TIME(TEST11 後的新架構)
    fine_cmd_offset: float = 0.0        # FINE 軌:實際 = TIME + 此值(test11b: +0.066)
    cont_cmd_offset: float = 0.0        # (保留相容)舊常數模型
    cont_saving_base: float = 0.0       # CONT 轉角節省 @Acc=100(test11b: 0.304;隨 100/Acc 放大)
    t_margin: float = 1.15
    max_lines: int = 3000
    calibrated: bool = False

    def overhead(self, smooth) -> float:
        """該平滑等級的固定開銷(秒)。

        實測(test4/test6):FINE=2 與 FINE=1 無法區分(差 <5ms);
        FINE=0 因為會預讀下一句,每點少約 65ms。
        """
        return self.c_fine0 if getattr(smooth, "value", smooth) == "FINE=0" else self.c

    @property
    def norm_weights(self) -> list[float]:
        s = sum(self.weights) or 1.0
        return [w / s for w in self.weights]

    @classmethod
    def load(cls, model: str | None = None, path: str | Path | None = None) -> "RobotParams":
        if path is None:
            path = PARAMS_DIR / "robot_params.yaml"
        p = Path(path)
        if not p.exists():
            return cls()
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        if not data:
            return cls()
        key = model if (model and model in data) else next(iter(data))
        entry = dict(data[key])
        tm = entry.pop("timing_model", {}) or {}
        entry.pop("robot", None)
        return cls(
            name=key,
            vmax=entry.get("vmax", [180.0] * 6),
            amax=entry.get("amax", [720.0] * 6),
            weights=entry.get("weights", [3, 3, 2, 1, 1, 1]),
            joint_limits=entry.get("joint_limits", {}) or {},
            k=float(tm.get("k", 1.0)),
            c=float(tm.get("c", 0.0)),
            c_fine0=float(tm.get("c_fine0", tm.get("c", 0.0))),
            cont_saving=float(tm.get("cont_saving", 0.0)),
            vel_max_pct=float(entry.get("vel_max_pct", 100.0)),
            k_od=float(tm.get("k_od", 1.0)),
            time_track_vel_pct=float(entry.get("time_track_vel_pct", 100.0)),
            single_track=bool(entry.get("single_track", False)),
            fine_cmd_offset=float(tm.get("fine_cmd_offset", 0.0)),
            cont_cmd_offset=float(tm.get("cont_cmd_offset", 0.0)),
            cont_saving_base=float(tm.get("cont_saving_base", 0.0)),
            t_margin=float(entry.get("t_margin", 1.15)),
            max_lines=int(entry.get("max_lines", 3000)),
            calibrated=bool(entry.get("calibrated", False)),
        )
