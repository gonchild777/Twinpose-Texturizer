"""資料類別:整條管線共用的型別定義。

設計原則:
- Frame.angles 一旦從輸入讀進來就 **永不修改**(形不動)。
- 管線各階段只往 Frame 上疊「標註」(role / smooth / acc / time_ms / vel ...)。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

AXES = ("J1", "J2", "J3", "J4", "J5", "J6")


class Role(str, Enum):
    """取樣點在舞句結構中的角色。"""

    ANCHOR = "anchor"      # 落在動作句點上 → 走 PTP_TIME(精確對時)
    PASS = "pass"          # 經過點 → 走 PTP + CONT(流暢通過)
    WAIT = "wait"          # 停頓卡


class Smooth(str, Enum):
    """HRSS 平滑階梯,由硬到滑。"""

    FINE2 = "FINE=2"
    FINE1 = "FINE=1"
    FINE0 = "FINE=0"
    CONT = "CONT"

    @property
    def is_fine(self) -> bool:
        return self is not Smooth.CONT


@dataclass
class Frame:
    """一個取樣點(TwinPose 的一張關鍵幀卡片)。"""

    time: float                          # 影片絕對秒數
    angles: dict[str, float]             # J1..J6,單位 degree —— 唯讀
    group: str = "default"

    # ---- 以下由管線階段填寫 ----
    role: Role = Role.PASS
    smooth: Smooth = Smooth.FINE1
    acc: int = 100                       # 1..100
    manual: bool = False                 # 使用者手動調整過 → 不被自動覆寫
    wait_sec: float | None = None        # 僅 Role.WAIT 使用

    # ---- 由 budget 階段填寫(擇一) ----
    time_ms: int | None = None           # ANCHOR:PTP_TIME 的 TIME=
    vel: int | None = None               # PASS:PTP 的 Vel=
    saturated: bool = False              # 觸發 T_min 飽和

    # ---- 診斷用 ----
    metrics: dict[str, float] = field(default_factory=dict)  # 對齊後的指標值

    def delta(self, other: "Frame") -> list[float]:
        """相對另一幀的各軸角度差(degree),順序同 AXES。"""
        return [self.angles[a] - other.angles[a] for a in AXES]


@dataclass
class Valley:
    """能量曲線上的一個低谷 = 動作的自然句點。"""

    time: float
    energy: float
    dwell: float = 0.0        # ω 低於門檻的持續時間(秒)
    jerk_peak: float = 0.0
    torque_peak: float = 0.0


@dataclass
class Report:
    """處理報告 —— 給 CLI 印出、給 Web UI 畫圖。"""

    anchors: int = 0
    pass_points: int = 0
    decimated: int = 0
    saturated_segments: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    timeline: list[dict[str, Any]] = field(default_factory=list)
    timing_estimated: bool = True        # 未載入校正值時為 True
    hybrid_anchors: int = 0              # 改走 PTP+FINE+Vel 超頻的錨點數(TEST9C 額定鎖)

    def add_warning(self, msg: str) -> None:
        if msg not in self.warnings:
            self.warnings.append(msg)

    def to_dict(self) -> dict[str, Any]:
        return {
            "anchors": self.anchors,
            "pass_points": self.pass_points,
            "decimated": self.decimated,
            "saturated_segments": self.saturated_segments,
            "warnings": self.warnings,
            "timing_estimated": self.timing_estimated,
            "hybrid_anchors": self.hybrid_anchors,
            "timeline": self.timeline,
        }
