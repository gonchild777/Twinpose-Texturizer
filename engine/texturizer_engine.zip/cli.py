#!/usr/bin/env python3
"""HRS Texturizer — 命令列介面。

用法:
    python cli.py export.json metrics.csv -o dance.hrs
    python cli.py dance.hrs metrics.csv --start-offset 2.5 --robot RA605
    python cli.py export.json metrics.csv --tempo 1.2 --sensitivity 55
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from core import Config, RobotParams, load_metrics, load_motion, run
from core.io_metrics import MetricsError
from core.io_twinpose import InputError


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="texturize",
        description="把 TwinPose 動作 + 指標 CSV 編譯成有質感的 HRS 程式。",
    )
    p.add_argument("motion", help="TwinPose Export JSON,或 HRS 文字檔")
    p.add_argument("metrics", help="指標 CSV(time_s, omega_total, energy, torque, jerk)")
    p.add_argument("-o", "--out", help="輸出 .hrs 路徑(預設:<motion>_textured.hrs)")
    p.add_argument("--report", help="輸出報告 JSON 路徑(預設:與 .hrs 同名 _report.json)")
    p.add_argument("--robot", default=None, help="手臂型號(對應 robot_params.yaml)")
    p.add_argument("--config", default=None, help="處理參數 YAML")
    p.add_argument("--robot-params", default=None, help="手臂參數 YAML")
    p.add_argument("--start-offset", type=float, default=0.0,
                   help="HRS 輸入時,第一個點對應的影片時刻(秒)")
    p.add_argument("--sensitivity", type=float, default=None, help="覆寫低谷靈敏度")
    p.add_argument("--tempo", type=float, default=None, help="整體變速(<1 快,>1 慢)")
    p.add_argument("--torque-gain", type=float, default=None, help="力度對比增益(預設 1.0)")
    p.add_argument("--jerk-gain", type=float, default=None, help="頓感判定增益(預設 1.0)")
    p.add_argument("--chord-tol", type=float, default=None, help="覆寫抽幀容差(度)")
    p.add_argument("--no-decimate", action="store_true", help="關閉抽幀")
    p.add_argument("-q", "--quiet", action="store_true", help="只輸出檔案,不印摘要")
    return p


def main(argv: list[str] | None = None) -> int:
    # 子命令:texturize web → 啟動本機網頁介面
    if argv is None:
        argv = sys.argv[1:]
    if argv and argv[0] == "web":
        from web.server import serve

        wp = argparse.ArgumentParser(prog="texturize web")
        wp.add_argument("--host", default="127.0.0.1")
        wp.add_argument("--port", type=int, default=8000)
        wa = wp.parse_args(argv[1:])
        serve(wa.host, wa.port)
        return 0

    args = build_parser().parse_args(argv)

    try:
        frames = load_motion(args.motion, start_offset=args.start_offset)
        metrics = load_metrics(args.metrics)
    except (InputError, MetricsError, FileNotFoundError) as exc:
        print(f"錯誤:{exc}", file=sys.stderr)
        return 1

    cfg = Config.load(args.config)
    if args.sensitivity is not None:
        cfg.valley.sensitivity = args.sensitivity
    if args.tempo is not None:
        cfg.style.tempo = args.tempo
    if args.torque_gain is not None:
        cfg.style.torque_gain = args.torque_gain
    if args.jerk_gain is not None:
        cfg.style.jerk_gain = args.jerk_gain
    if args.chord_tol is not None:
        cfg.decimate.chord_tol_deg = args.chord_tol
    if args.no_decimate:
        cfg.decimate.enabled = False

    rp = RobotParams.load(args.robot, args.robot_params)

    stem = Path(args.motion).stem
    result = run(frames, metrics, cfg=cfg, rp=rp, name=stem.upper())

    out = Path(args.out) if args.out else Path(f"{stem}_textured.hrs")
    out.write_text(result.hrs, encoding="utf-8")
    rep = Path(args.report) if args.report else out.with_name(out.stem + "_report.json")
    rep.write_text(
        json.dumps(result.report.to_dict(), ensure_ascii=False, indent=2), encoding="utf-8"
    )

    if not args.quiet:
        r = result.report
        print(f"✓ {out}")
        print(f"  錨點 {r.anchors} · 經過點 {r.pass_points} · 抽掉 {r.decimated} 點")
        if r.timing_estimated:
            print("  ⚠ 手臂尚未校正,時序為估計值")
        for w in r.warnings:
            print(f"  ⚠ {w}")
        print(f"  報告:{rep}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
