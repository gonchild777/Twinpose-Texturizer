#!/usr/bin/env python3
"""轉接器:把分析專案輸出的 SmoothedMetrics CSV 轉成本工具的格式。

分析端格式(realtime-dance-analysis):
    frameIndex, EnergyFlow, Volume, PathCurvature, CoMHeight, PosturalSway,
    SwayRaw, LeftAngularIntensity, RightAngularIntensity, SyncCorrelation,
    TransitionTorque, Jerk

本工具格式:
    time_s, omega_total, energy, torque, jerk

對應關係:
    time_s      = frameIndex / fps          (需給影片 fps)
    omega_total = Left + Right AngularIntensity   ← 左右半身角速度總和,
                  正是白皮書 Ω_L + Ω_R 的定義,用來判斷「有沒有真的停住」
    energy      = EnergyFlow
    torque      = TransitionTorque
    jerk        = Jerk

用法:
    python adapt_metrics.py in.csv -o out.csv --fps 30
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

SRC_REQUIRED = (
    "frameIndex",
    "EnergyFlow",
    "LeftAngularIntensity",
    "RightAngularIntensity",
    "TransitionTorque",
    "Jerk",
)


def adapt(src: Path, dst: Path, fps: float) -> int:
    with src.open(newline="", encoding="utf-8-sig") as fh:
        rows = [{(k or "").strip(): v for k, v in r.items()} for r in csv.DictReader(fh)]
    if not rows:
        raise SystemExit("CSV 沒有資料。")
    missing = [c for c in SRC_REQUIRED if c not in rows[0]]
    if missing:
        raise SystemExit(f"來源 CSV 缺少欄位:{', '.join(missing)}")

    out = []
    for r in rows:
        out.append(
            {
                "time_s": round(float(r["frameIndex"]) / fps, 4),
                "omega_total": round(
                    float(r["LeftAngularIntensity"]) + float(r["RightAngularIntensity"]), 5
                ),
                "energy": round(float(r["EnergyFlow"]), 5),
                "torque": round(float(r["TransitionTorque"]), 5),
                "jerk": round(float(r["Jerk"]), 3),
            }
        )

    with dst.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(out[0].keys()))
        w.writeheader()
        w.writerows(out)
    return len(out)


def main() -> int:
    ap = argparse.ArgumentParser(description="分析端 CSV → texturizer CSV")
    ap.add_argument("src")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--fps", type=float, default=30.0, help="影片幀率(預設 30)")
    a = ap.parse_args()
    n = adapt(Path(a.src), Path(a.out), a.fps)
    print(f"✓ {a.out}({n} 幀 @ {a.fps}fps = {n / a.fps:.2f}s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
