#!/usr/bin/env python3
"""M0 校正:產生掃描程式,並用實測時間擬合 timing_model。

為什麼需要:規格表的 vmax/amax 是理論值,實機還有 S 曲線圓角、
指令處理開銷、速度標定誤差。時間預算(budget)全靠這個模型,
不校正的話 CONT 段時序誤差可能到 20–50%。

流程:
  1) python calibrate.py gen --robot RA605 -o scan.hrs
  2) 上機執行 scan.hrs,記錄每段實際耗時(碼表或控制器 log),
     填進 measurements.csv:  axis,delta_deg,vel_pct,acc_pct,measured_s
  3) python calibrate.py fit measurements.csv --robot RA605
     → 印出 k / c,填回 params/robot_params.yaml 並把 calibrated 設 true
"""
from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from core.config import RobotParams  # noqa: E402

# 掃描網格:位移 × 速度 × 加速度
DELTAS = (10.0, 45.0, 90.0)
VELS = (5, 10, 25, 50, 75, 100)
ACCS = (30, 65, 100)


def gen(rp: RobotParams, axis: int = 1) -> str:
    """產生單軸掃描程式。其餘軸保持 0,讓限制軸明確。"""
    lines = [
        f"'--- timing calibration | {rp.name} | axis J{axis} ---",
        "'--- 每段執行前後記錄時間,填入 measurements.csv ---",
        "",
        f"E6AXIS PHOME={{{', '.join(f'A{i+1}=0.000' for i in range(6))}}}",
        "PTP PHOME FINE=2 Vel=20% Acc=50% TOOL[0] BASE[0]",
        "",
    ]
    idx = 1
    for d in DELTAS:
        for acc in ACCS:
            for vel in VELS:
                target = {f"A{i+1}": 0.0 for i in range(6)}
                target[f"A{axis}"] = d
                body = ", ".join(f"{k}={v:.3f}" for k, v in target.items())
                lines += [
                    f"E6AXIS PC{idx}={{{body}}}",
                    f"PTP PC{idx} FINE=2 Vel={vel}% Acc={acc}% TOOL[0] BASE[0]"
                    f"  'd={d} vel={vel} acc={acc}",
                    f"PTP PHOME FINE=2 Vel={vel}% Acc={acc}% TOOL[0] BASE[0]  '回原點",
                    "",
                ]
                idx += 1
    lines.append("'--- end ---")
    return "\n".join(lines)


def fit(csv_path: Path, rp: RobotParams) -> tuple[float, float]:
    """最小平方擬合 T = k·(D/v) + v/a + c 的 k 與 c。"""
    xs, ys = [], []
    with csv_path.open(newline="", encoding="utf-8-sig") as fh:
        for r in csv.DictReader(fh):
            axis = int(r["axis"]) - 1
            d = float(r["delta_deg"])
            v = rp.vmax[axis] * float(r["vel_pct"]) / 100.0
            a = rp.amax[axis] * float(r["acc_pct"]) / 100.0
            measured = float(r["measured_s"])
            xs.append(d / max(v, 1e-9))
            ys.append(measured - v / max(a, 1e-9))   # 移項後只剩 k·x + c
    if len(xs) < 3:
        raise SystemExit("量測筆數太少(至少 3 筆)。")
    A = np.vstack([np.array(xs), np.ones(len(xs))]).T
    (k, c), *_ = np.linalg.lstsq(A, np.array(ys), rcond=None)
    pred = A @ np.array([k, c])
    err = np.abs(pred - np.array(ys)) / np.maximum(np.array(ys), 1e-6)
    print(f"k = {k:.4f}\nc = {c:.4f}")
    print(f"平均相對誤差 {err.mean()*100:.1f}% · 最大 {err.max()*100:.1f}%")
    if err.mean() > 0.05:
        print("⚠ 誤差 > 5%,建議增加量測點或分軸各自擬合。")
    return float(k), float(c)


def main() -> int:
    p = argparse.ArgumentParser(description="手臂時序校正工具")
    sub = p.add_subparsers(dest="cmd", required=True)

    g = sub.add_parser("gen", help="產生掃描 HRS")
    g.add_argument("--robot", default=None)
    g.add_argument("--axis", type=int, default=1)
    g.add_argument("-o", "--out", default="scan.hrs")

    f = sub.add_parser("fit", help="以實測資料擬合時序模型")
    f.add_argument("measurements", help="axis,delta_deg,vel_pct,acc_pct,measured_s")
    f.add_argument("--robot", default=None)

    args = p.parse_args()
    rp = RobotParams.load(args.robot)

    if args.cmd == "gen":
        Path(args.out).write_text(gen(rp, args.axis), encoding="utf-8")
        n = len(DELTAS) * len(VELS) * len(ACCS)
        print(f"✓ {args.out}({n} 組測試,軸 J{args.axis})")
        print("  執行後把實測時間填入 measurements.csv,再跑 fit。")
    else:
        fit(Path(args.measurements), rp)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
