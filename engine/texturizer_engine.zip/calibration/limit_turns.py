#!/usr/bin/env python3
"""轉折限幅器:只在「跑不動」的段落,把關鍵幀朝鄰居等比收攏到剛好可行。

守則 1(引擎永不改角度)不變 —— 本工具是使用者顯式執行的改形前處理,
與 rescale_export 同級,並輸出完整的修改清單供審閱。

演算法(Gauss-Seidel 局部鬆弛):
  對每個內部關鍵幀 P[i],若其相鄰兩段任一超出物理下限:
    以時間加權內插 target = lerp(P[i-1], P[i+1]) 為收攏中心,
    二分搜尋最大保留比例 s,使兩鄰段皆可行,P[i] ← target + s·(P[i]−target)。
  重複掃描直到收斂。等比作用於全部六軸 → 姿勢「性格」保留、幅度縮小。

可行判準與單軌引擎一致:t_min(margin=1, Acc=100, 175%) − CONT 轉角折讓。
"""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from core.config import RobotParams
from core.budget import t_min
AXES = ["J1","J2","J3","J4","J5","J6"]

def floor_s(delta, rp):
    f = t_min(delta, rp.vmax, rp.amax, 1.0, 100, rp.c, rp.time_track_vel_pct)
    return max(f - (rp.fine_cmd_offset + rp.cont_cmd_offset), 0.06)

def relax(kf, rp, safety=0.97, iters=60):
    T=[float(k["time"]) for k in kf]
    A=[[float(k["angles"][a]) for a in AXES] for k in kf]
    orig=[row[:] for row in A]
    def d(i,j): return [b-a for a,b in zip(A[i],A[j])]
    def ok(i):  # 段 i-1→i
        avail=(T[i]-T[i-1])*safety
        return floor_s(d(i-1,i), rp) <= avail
    changed_any=set()
    for _ in range(iters):
        moved=False
        for i in range(1,len(kf)-1):
            if ok(i) and ok(i+1): continue
            w=(T[i]-T[i-1])/max(T[i+1]-T[i-1],1e-9)
            tgt=[a+(b-a)*w for a,b in zip(A[i-1],A[i+1])]
            base=A[i][:]
            lo,hi=0.0,1.0
            for _ in range(36):
                mid=(lo+hi)/2
                A[i]=[t+ (b-t)*mid for t,b in zip(tgt,base)]
                if ok(i) and ok(i+1): lo=mid
                else: hi=mid
            A[i]=[t+(b-t)*lo for t,b in zip(tgt,base)]
            if lo<0.999: moved=True; changed_any.add(i)
        if not moved: break
    # 端點(只有單側鄰居)
    for i,(j,) in ((0,(1,)),(len(kf)-1,(len(kf)-2,))):
        if not (floor_s(d(min(i,j),max(i,j)),rp) <= (abs(T[i]-T[j]))*safety):
            base=A[i][:]; tgt=A[j][:]
            lo,hi=0.0,1.0
            for _ in range(36):
                mid=(lo+hi)/2
                A[i]=[t+(b-t)*mid for t,b in zip(tgt,base)]
                if floor_s(d(min(i,j),max(i,j)),rp) <= abs(T[i]-T[j])*safety: lo=mid
                else: hi=mid
            A[i]=[t+(b-t)*lo for t,b in zip(tgt,base)]
            changed_any.add(i)
    for k,row in zip(kf,A):
        k["angles"]={a:round(v,2) for a,v in zip(AXES,row)}
    rep=[]
    for i in sorted(changed_any):
        dmax=max(abs(a-b) for a,b in zip(A[i],orig[i]))
        ax=AXES[max(range(6), key=lambda x: abs(A[i][x]-orig[i][x]))]
        rep.append((round(T[i],2), ax, round(dmax,1)))
    return rep

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("src"); ap.add_argument("-o","--out",required=True)
    ap.add_argument("--robot",default="MEASURED_AUTO100")
    a=ap.parse_args()
    doc=json.loads(Path(a.src).read_text(encoding="utf-8"))
    kf=[k for k in doc["jointsData"] if k.get("group")!="wait"]
    rp=RobotParams.load(a.robot)
    rep=relax(kf,rp)
    Path(a.out).write_text(json.dumps(doc,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"✓ {a.out} — 收攏 {len(rep)} 個關鍵幀(其餘未動):")
    for t,ax,dm in rep: print(f"   t={t:6.2f}s  {ax} 最多改 {dm}°")
    return 0

if __name__=="__main__": raise SystemExit(main())
