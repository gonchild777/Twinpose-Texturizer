#!/usr/bin/env python3
"""關鍵幀規劃器:從指標 CSV 算出「該在哪些秒數切關鍵幀」。

動機:固定間隔取樣(如 0.5s)按時鐘切,不按動作切——
快段的轉折被切掉(失真)、慢段浪費點數。
本工具改為:
  1. ω 波谷 → 必切(動作句點:姿勢到位/方向反轉,舞蹈的「關節」)
  2. Torque 尖峰 → 必切(hit 瞬間,保證重拍姿勢被抓到)
  3. 其間按「累積角位移」等量插點:動得多就密、動得少就疏
  最小間距綁手臂能力(預設 0.35s)——取樣快過手臂反應沒有意義。

輸入:adapt_metrics.py 轉出的 CSV(time_s, omega_total, energy, torque, jerk)
輸出:切點清單(秒 + 30fps 幀號 + 原因),與均勻取樣的失真對比。

用法:
    python plan_keyframes.py metrics.csv
    python plan_keyframes.py metrics.csv --min-dt 0.35 --max-dt 1.2 -o plan.csv
    python plan_keyframes.py metrics.csv --budget 40      # 限制總點數
"""
from __future__ import annotations

import argparse
import csv
import math
from pathlib import Path


def load(path: str):
    rows = list(csv.DictReader(open(path, encoding="utf-8-sig")))
    t = [float(r["time_s"]) for r in rows]
    w = [float(r["omega_total"]) for r in rows]
    tq = [float(r["torque"]) for r in rows]
    return t, w, tq


def smooth(x, k=7):
    """簡單零相位:前後對稱窗平均(k 奇數)。"""
    h = k // 2
    out = []
    for i in range(len(x)):
        lo, hi = max(0, i - h), min(len(x), i + h + 1)
        out.append(sum(x[lo:hi]) / (hi - lo))
    return out


def local_minima(t, x, min_gap: float, prominence_pct: float = 20.0):
    """波谷:局部極小 + 突出度門檻(相對全距百分比),近距合併取更低者。"""
    span = max(x) - min(x) or 1.0
    prom = span * prominence_pct / 100.0
    cand = []
    for i in range(1, len(x) - 1):
        if x[i] <= x[i - 1] and x[i] <= x[i + 1]:
            left = max(x[max(0, i - 30):i + 1])
            right = max(x[i:i + 31])
            if min(left, right) - x[i] >= prom:
                cand.append(i)
    out = []
    for i in cand:
        if out and t[i] - t[out[-1]] < min_gap:
            if x[i] < x[out[-1]]:
                out[-1] = i
        else:
            out.append(i)
    return out


def local_maxima(t, x, min_gap: float, top_pct: float = 85.0):
    thr = sorted(x)[int(len(x) * top_pct / 100.0)]
    cand = [i for i in range(1, len(x) - 1)
            if x[i] >= x[i - 1] and x[i] >= x[i + 1] and x[i] >= thr]
    out = []
    for i in cand:
        if out and t[i] - t[out[-1]] < min_gap:
            if x[i] > x[out[-1]]:
                out[-1] = i
        else:
            out.append(i)
    return out


def cum_disp(t, w):
    """累積角位移 ∫ω dt(單位:deg,ω 為 deg/s 時)。"""
    c = [0.0]
    for i in range(1, len(t)):
        c.append(c[-1] + (w[i] + w[i - 1]) / 2 * (t[i] - t[i - 1]))
    return c


def plan(t, w, tq, min_dt, max_dt, disp_step, budget=None,
         valley_gap=0.5, hit_gap=0.5):
    ws = smooth(w)
    forced = {}
    for i in local_minima(t, ws, valley_gap):
        forced[round(t[i], 3)] = "valley"
    for i in local_maxima(t, smooth(tq), hit_gap):
        key = round(t[i], 3)
        forced.setdefault(key, "hit")
    forced[round(t[0], 3)] = "start"
    forced[round(t[-1], 3)] = "end"

    anchors = sorted(forced)
    # 強制點本身也要守最小間距(保留優先序:start/end > valley > hit)
    rank = {"start": 0, "end": 0, "valley": 1, "hit": 2}
    keep = [anchors[0]]
    for a in anchors[1:]:
        if a - keep[-1] < min_dt:
            if rank[forced[a]] < rank[forced[keep[-1]]] and forced[keep[-1]] not in ("start", "end"):
                keep[-1] = a
        else:
            keep.append(a)
    anchors = keep

    C = cum_disp(t, w)

    def disp_at(x):
        # 線性內插累積位移
        for i in range(1, len(t)):
            if t[i] >= x:
                r = (x - t[i - 1]) / (t[i] - t[i - 1] or 1e-9)
                return C[i - 1] + r * (C[i] - C[i - 1])
        return C[-1]

    keys = []
    for a, b in zip(anchors, anchors[1:]):
        keys.append((a, forced[a]))
        gap = b - a
        d = disp_at(b) - disp_at(a)
        n = max(int(math.ceil(gap / max_dt)),
                int(math.ceil(d / disp_step))) - 1
        n = min(n, int(gap / min_dt) - 1) if gap / min_dt >= 2 else 0
        if n > 0:
            step = d / (n + 1)
            target = disp_at(a) + step
            j = 0
            for k in range(n):
                while j < len(t) - 1 and disp_at(t[j]) < target:
                    j += 1
                x = t[j]
                if x - keys[-1][0] >= min_dt and b - x >= min_dt:
                    keys.append((round(x, 3), "infill"))
                target += step
    keys.append((anchors[-1], forced[anchors[-1]]))

    # 保底:純位移插點會整段跳過「幾乎不動」的長段(位移都累積在別處),
    # 但停頓段仍需保底點釘住姿勢 —— 超過 max_dt 的間隙以時間等分補 hold 點。
    fixed = [keys[0]]
    for x, kind in keys[1:]:
        while x - fixed[-1][0] > max_dt + 1e-9:
            nxt = fixed[-1][0] + max_dt
            if x - nxt < min_dt:            # 別擠出過近的尾點
                break
            fixed.append((round(nxt, 3), "hold"))
        fixed.append((x, kind))
    keys = fixed

    if budget and len(keys) > budget:
        # 超出預算:等比抽掉 infill(保留 valley/hit)
        infill = [k for k in keys if k[1] == "infill"]
        drop = len(keys) - budget
        if drop > 0 and infill:
            step = max(1, len(infill) // drop)
            to_drop = set(id(x) for x in infill[::step][:drop])
            keys = [k for k in keys if id(k) not in to_drop]
    return keys


def main() -> int:
    ap = argparse.ArgumentParser(description="從指標 CSV 規劃關鍵幀切點")
    ap.add_argument("csv")
    ap.add_argument("--min-dt", type=float, default=0.35, help="最小間距(手臂能力)")
    ap.add_argument("--max-dt", type=float, default=1.2, help="最大間距(慢段保底)")
    ap.add_argument("--disp-step", type=float, default=25.0,
                    help="每段目標累積位移(ω 單位×秒;越小越密)")
    ap.add_argument("--budget", type=int, help="總點數上限")
    ap.add_argument("--fps", type=float, default=30.0)
    ap.add_argument("-o", "--out", help="輸出切點 CSV")
    a = ap.parse_args()

    t, w, tq = load(a.csv)
    keys = plan(t, w, tq, a.min_dt, a.max_dt, a.disp_step, a.budget)

    dur = t[-1] - t[0]
    uni_n = int(dur / 0.5) + 1
    gaps = [b - x for (x, _), (b, _) in zip(keys, keys[1:])]
    print(f"曲長 {dur:.1f}s → 規劃 {len(keys)} 點"
          f"(均勻 0.5s 取樣為 {uni_n} 點)")
    print(f"間距:最小 {min(gaps):.2f}s 中位 {sorted(gaps)[len(gaps)//2]:.2f}s 最大 {max(gaps):.2f}s")
    from collections import Counter
    print("組成:", dict(Counter(k for _, k in keys)))
    print(f"\n{'秒':>8s}{'幀#':>7s}  原因")
    for x, kind in keys:
        print(f"{x:8.2f}{int(round(x*a.fps)):7d}  {kind}")

    if a.out:
        with open(a.out, "w", newline="", encoding="utf-8") as fh:
            wr = csv.writer(fh)
            wr.writerow(["time_s", f"frame@{a.fps:.0f}fps", "reason"])
            for x, kind in keys:
                wr.writerow([x, int(round(x * a.fps)), kind])
        print(f"\n✓ {a.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
