#!/usr/bin/env python3
"""可行性檢查:一份動作檔有多少比例的指令,手臂實際做不到?

檢查三件事:
  1. 速度可行性 —— 每段所需的最短時間 vs 關鍵幀給的時間
  2. 關節極限   —— 角度是否超出原廠動作範圍
  3. 建議調整   —— 要縮多少振幅 / 放慢多少倍才可行

可同時比較多組手臂參數(例如實測值 vs 原廠規格),
因為兩者差距本身就是重要資訊。

用法:
    python check_feasibility.py motion.json
    python check_feasibility.py motion.json --robots MEASURED_AUTO100 RA610_1476
    python check_feasibility.py motion.json --tempo 2.0 --amplitude 0.35
    python check_feasibility.py motion.json --csv out.csv
"""
from __future__ import annotations

import argparse
import csv
import statistics as st
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core.budget import limiting_axis, t_min  # noqa: E402
from core.config import RobotParams  # noqa: E402
from core.io_twinpose import load_motion  # noqa: E402
from core.models import AXES, Frame, Role  # noqa: E402


def scale_for(delta, budget, rp, acc=100) -> float:
    """位移要縮到幾成才做得到(數值二分,因為大小位移的時間關係不同)。"""
    if t_min(delta, rp.vmax, rp.amax, 1.0, acc, rp.c, rp.vel_max_pct) <= budget:
        return 1.0
    lo, hi = 0.0, 1.0
    for _ in range(40):
        mid = (lo + hi) / 2
        if t_min([d * mid for d in delta], rp.vmax, rp.amax, 1.0, acc, rp.c, rp.vel_max_pct) <= budget:
            lo = mid
        else:
            hi = mid
    return lo


def check_speed(frames: list[Frame], rp, tempo: float, amp: float, acc: int):
    rows = []
    for i in range(1, len(frames)):
        prev, f = frames[i - 1], frames[i]
        if f.role is Role.WAIT or prev.role is Role.WAIT:
            continue
        delta = [d * amp for d in f.delta(prev)]
        ax, dd = limiting_axis(delta, rp.vmax)
        avail = (f.time - prev.time) * tempo
        need = t_min(delta, rp.vmax, rp.amax, 1.0, acc, rp.c, rp.vel_max_pct)
        rows.append(
            {
                "seg": i,
                "t": round(f.time, 2),
                "axis": AXES[ax],
                "deg": round(dd, 1),
                "avail_s": round(avail, 3),
                "need_s": round(need, 3),
                "ratio": round(need / max(avail, 1e-9), 2),
                "ok": need <= avail,
                "scale": round(scale_for(delta, avail, rp, acc), 3),
            }
        )
    return rows


def check_limits(frames: list[Frame], rp):
    """角度是否超出原廠動作範圍。貼齊極限值(而非超出)通常代表上游已夾住。"""
    out = []
    if not rp.joint_limits:
        return out
    for axis, (lo, hi) in rp.joint_limits.items():
        vals = [(f.time, f.angles[axis]) for f in frames if f.role is not Role.WAIT]
        over = [(t, v) for t, v in vals if v < lo - 1e-6 or v > hi + 1e-6]
        at = [(t, v) for t, v in vals if abs(v - lo) < 1e-6 or abs(v - hi) < 1e-6]
        if over:
            out.append((axis, "超出", lo, hi, over))
        elif len(at) >= 2:
            out.append((axis, "貼齊", lo, hi, at))
    return out


def report(name: str, frames: list[Frame], rp, tempo: float, amp: float, acc: int, verbose: bool):
    rows = check_speed(frames, rp, tempo, amp, acc)
    bad = [r for r in rows if not r["ok"]]
    ratios = [r["ratio"] for r in rows]
    scales = [r["scale"] for r in rows]

    print(f"\n{'='*74}")
    print(f" {name}   (tempo×{tempo}  振幅×{amp:.0%}  Acc={acc}%)")
    print(f"{'='*74}")
    print(f"  可行 {len(rows)-len(bad)}/{len(rows)} 段 "
          f"({(len(rows)-len(bad))/max(len(rows),1)*100:.0f}%) · "
          f"做不到 {len(bad)} 段 ({len(bad)/max(len(rows),1)*100:.0f}%)")
    if rows:
        print(f"  所需時間/可用時間:中位 {st.median(ratios):.2f}x  最大 {max(ratios):.2f}x")
        print(f"  要全部可行需把振幅縮到 {min(scales)*100:.0f}%;"
              f"半數可行需 {st.median(scales)*100:.0f}%")
        worst = max(rows, key=lambda r: r["ratio"])
        print(f"  最吃緊:第 {worst['seg']} 段 @{worst['t']}s "
              f"{worst['axis']} 走 {worst['deg']}° "
              f"需 {worst['need_s']}s 但只有 {worst['avail_s']}s")

    lim = check_limits(frames, rp)
    if lim:
        print("  關節極限:")
        for axis, kind, lo, hi, hits in lim:
            ts = ", ".join(f"{t:.1f}s" for t, _ in hits[:5])
            print(f"    {axis} {kind}範圍 [{lo}, {hi}] —— {len(hits)} 次 (t={ts})")
    elif rp.joint_limits:
        print("  關節極限:全部在範圍內 ✓")

    if verbose and rows:
        print(f"\n  {'段':>3s}{'時間':>7s}{'限制軸':>7s}{'位移°':>8s}"
              f"{'可用s':>8s}{'需要s':>8s}{'倍率':>7s}{'可行':>6s}")
        for r in rows:
            print(f"  {r['seg']:3d}{r['t']:7.1f}{r['axis']:>7s}{r['deg']:8.1f}"
                  f"{r['avail_s']:8.2f}{r['need_s']:8.2f}{r['ratio']:7.2f}"
                  f"{'✓' if r['ok'] else '✗':>6s}")
    return rows


def main() -> int:
    ap = argparse.ArgumentParser(description="動作檔可行性檢查")
    ap.add_argument("motion", help="TwinPose Export JSON 或 .hrb")
    ap.add_argument("--robots", nargs="+", default=["MEASURED_AUTO100", "RA610_1476"])
    ap.add_argument("--tempo", type=float, default=1.0, help="整體變速倍率")
    ap.add_argument("--amplitude", type=float, default=1.0, help="振幅縮放(0-1)")
    ap.add_argument("--acc", type=int, default=100, help="加速度百分比")
    ap.add_argument("--start-offset", type=float, default=0.0)
    ap.add_argument("--csv", help="逐段結果輸出路徑")
    ap.add_argument("-v", "--verbose", action="store_true", help="列出每一段")
    a = ap.parse_args()

    frames = load_motion(a.motion, start_offset=a.start_offset)
    motion_n = sum(1 for f in frames if f.role is not Role.WAIT)
    print(f"動作檔:{Path(a.motion).name} —— {motion_n} 點,"
          f"總長 {frames[-1].time:.1f}s(變速後 {frames[-1].time * a.tempo:.1f}s)")

    last = []
    for name in a.robots:
        rp = RobotParams.load(name)
        last = report(name, frames, rp, a.tempo, a.amplitude, a.acc, a.verbose)

    if a.csv and last:
        with open(a.csv, "w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(last[0].keys()))
            w.writeheader()
            w.writerows(last)
        print(f"\n逐段結果:{a.csv}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
