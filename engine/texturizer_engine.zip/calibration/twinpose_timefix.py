#!/usr/bin/env python3
"""TwinPose 直出 .hrb → 時序修正版(無質感,只改 TIME)。

用法:
  python calibration/twinpose_timefix.py dance.hrb -o dance_fixed.hrb --timer
  # 實跑後回填實測,自動算下一版 gain:
  python calibration/twinpose_timefix.py dance.hrb -o v2.hrb --timer --measured 1.2368:195.276
  (--measured 可重複:gain:實測秒數,依時間順序)
"""
import argparse, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from core.timefix import fix_timing, next_gain, TimefixCfg  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("src"); ap.add_argument("-o", "--out", required=True)
ap.add_argument("--timer", action="store_true", help="插入 $T[1] 計時器")
ap.add_argument("--gain", type=float, help="手動指定償還增益")
ap.add_argument("--measured", action="append", default=[], metavar="GAIN:SECONDS")
a = ap.parse_args()
text = Path(a.src).read_text(encoding="utf-8")
base = fix_timing(text, gain=1.0)
g = a.gain
if a.measured:
    hist = [{"gain": float(x.split(":")[0]), "measured_s": float(x.split(":")[1])} for x in a.measured]
    g = next_gain(hist, base.schedule_s, base.model_debt_s)
r = fix_timing(text, gain=g, timer=a.timer)
Path(a.out).write_text(r.hrb, encoding="utf-8")
print(f"排程 {r.schedule_s:.2f}s | 直出預測 {r.raw_pred_s:.1f}s | 修正後預測 {r.fixed_pred_s:.1f}s")
print(f"gain {r.gain} | 跟不上 {len(r.saturated)} 段 | 償還 {r.repaid_s:.2f}s 分攤到 {len(r.repaid_segs)} 段 → {a.out}")
