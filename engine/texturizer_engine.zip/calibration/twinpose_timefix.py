#!/usr/bin/env python3
"""TwinPose 直出 .hrb → 時序修正版(無質感,只改 TIME)。

用法:
  python calibration/twinpose_timefix.py dance.hrb -o dance_fixed.hrb --timer
  # 實跑後回填實測,自動算下一版:
  python calibration/twinpose_timefix.py dance.hrb -o v2.hrb --timer --measured 0:195.276
  (--measured 可重複:TRIM:實測秒數,依時間順序;第一版 TRIM = 0)
"""
import argparse, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from core.timefix import fix_timing, next_trim  # noqa: E402

ap = argparse.ArgumentParser()
ap.add_argument("src"); ap.add_argument("-o", "--out", required=True)
ap.add_argument("--timer", action="store_true", help="插入 $T[1] 計時器")
ap.add_argument("--trim", type=float, default=None, help="手動指定要縮短的秒數(負=加長)")
ap.add_argument("--measured", action="append", default=[], metavar="TRIM:SECONDS")
a = ap.parse_args()
text = Path(a.src).read_text(encoding="utf-8")
base = fix_timing(text)
trim = a.trim if a.trim is not None else 0.0
if a.measured:
    hist = [{"trim_s": float(x.split(":")[0]), "measured_s": float(x.split(":")[1])} for x in a.measured]
    trim = next_trim(hist, base.schedule_s)
r = fix_timing(text, timer=a.timer, trim_s=trim)
Path(a.out).write_text(r.hrb, encoding="utf-8")
print(f"排程 {r.schedule_s:.2f}s | 直出預測 {r.raw_pred_s:.1f}s | 修正後預測 {r.fixed_pred_s:.1f}s")
print(f"trim {r.trim_s:+.3f}s(套用 {r.trim_applied_s:+.3f}s)| 跟不上 {len(r.saturated)} 段 | 償還 {r.repaid_s:.2f}s 分攤到 {len(r.repaid_segs)} 段 → {a.out}")
