#!/usr/bin/env python3
"""振幅縮放器:把 TwinPose export 的角度繞著各軸對映中心等比縮小。

為什麼可以這樣做:TwinPose 的 pose→angle 對映是線性的,
所以「縮放已錄的角度」≡「收窄 AL/AR 後重新擷取」(範圍內資料完全等價)。
本工具同時改寫 groups 裡的 AL/AR/AHL/AHR,讓檔案自洽,
之後在 TwinPose 開啟此檔也會用新的對映範圍。

注意:texturizer 本體永不修改角度;改「形」是本工具的顯式職責,
由使用者主動執行。

用法:
    python rescale_export.py in.json -o out.json --scale 0.35
    python rescale_export.py in.json -o out.json --scale 0.35 --axis-scale J5=0.5
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

MAP_KEYS = ("AL", "AR", "AHL", "AHR")   # 只縮輸出端(機器角度),不動 pose 輸入端 PL/PR


def centers_from_groups(doc: dict) -> dict[str, float]:
    """各軸縮放中心 =(AL+AR)/2。對映全零的軸(如 J4/J6)中心為 0。"""
    out: dict[str, float] = {}
    for g in doc.get("groups", []):
        for axis, cfg in g.get("data", {}).items():
            md = cfg.get("mappingData", {})
            out[axis] = (float(md.get("AL", 0)) + float(md.get("AR", 0))) / 2.0
    return out


def rescale(doc: dict, scale: float, per_axis: dict[str, float]) -> dict:
    centers = centers_from_groups(doc)
    factor = {a: per_axis.get(a, scale) for a in
              {**centers, **{f"J{i}": 0 for i in range(1, 7)}}}

    # 1) 縮放已錄角度
    for kf in doc.get("jointsData", []):
        if kf.get("group") == "wait":
            continue
        for axis, val in kf.get("angles", {}).items():
            c = centers.get(axis, 0.0)
            kf["angles"][axis] = round(c + (float(val) - c) * factor.get(axis, scale), 2)

    # 2) 同步收窄對映範圍(維持檔案自洽)
    for g in doc.get("groups", []):
        for axis, cfg in g.get("data", {}).items():
            md = cfg.get("mappingData", {})
            c = centers.get(axis, 0.0)
            f = factor.get(axis, scale)
            for k in MAP_KEYS:
                if k in md:
                    md[k] = round(c + (float(md[k]) - c) * f, 1)
    return doc


def main() -> int:
    ap = argparse.ArgumentParser(description="TwinPose export 振幅縮放")
    ap.add_argument("src")
    ap.add_argument("-o", "--out", required=True)
    ap.add_argument("--scale", type=float, default=0.35, help="全軸縮放比(預設 0.35)")
    ap.add_argument("--axis-scale", nargs="*", default=[],
                    help="個別軸覆寫,如 J5=0.5")
    a = ap.parse_args()

    per_axis = {}
    for item in a.axis_scale:
        k, v = item.split("=")
        per_axis[k.strip()] = float(v)

    doc = json.loads(Path(a.src).read_text(encoding="utf-8"))
    centers = centers_from_groups(doc)
    doc = rescale(doc, a.scale, per_axis)
    Path(a.out).write_text(json.dumps(doc, ensure_ascii=False, indent=2), encoding="utf-8")

    print(f"✓ {a.out}(全軸 ×{a.scale}" +
          (f",覆寫 {per_axis}" if per_axis else "") + ")")
    print("  新對映範圍(請同步填回 TwinPose 以便日後擷取一致):")
    for g in doc.get("groups", []):
        for axis, cfg in sorted(g.get("data", {}).items()):
            md = cfg.get("mappingData", {})
            if md.get("AL") == md.get("AR"):
                continue
            print(f"    {axis}: AL={md.get('AL')}  AR={md.get('AR')}"
                  f"  (中心 {centers.get(axis, 0):.0f} 不變)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
