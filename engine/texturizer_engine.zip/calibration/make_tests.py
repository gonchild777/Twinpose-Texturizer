#!/usr/bin/env python3
"""產生實機/離線驗證用的測試程式(.hrb),內建 HRSS 計時器。

計時方式(手冊 8.1.2):
    $T[n] = 0
    WAIT SEC 0          ← 必須,停止程式預讀,否則計時點會跑掉
    $T_STOP[n] = FALSE  ← 開始
    ... 受測動作 ...
    WAIT SEC 0          ← 必須
    $T_STOP[n] = TRUE   ← 停止
單位 ms,共 $T[1]~$T[20],程式結束後數值保留 → 在 Timer 分頁一次抄完。

精度限制:手冊載明「1ms 為單位,精準度至 55ms」。
因此短段落一律**重複多次量總和**,再自行除以次數 —— 誤差同步被除掉。

設計原則:
- 只用使用者既有的安全點位,不自創姿態
- 每組測試在相同幾何上只變動一個參數
- 每支程式開頭慢速歸位,確保起始狀態一致

用法:
    python make_tests.py -o tests_hrb
"""
from __future__ import annotations

import argparse
from pathlib import Path

# 取自實機檔案 test_acc.hrb 的已知安全點位
POSE_A = {"A1": -71.3, "A2": -47.1, "A3": -75.2, "A4": 0, "A5": -11.6, "A6": 0}
POSE_B = {"A1": 55.9, "A2": -10.4, "A3": -69.9, "A4": 0, "A5": -22.4, "A6": 0}
POSE_C = {"A1": 39.9, "A2": -8.6, "A3": 41.0, "A4": 0, "A5": -18.3, "A6": 0}
POSE_D = {"A1": 67.3, "A2": 21.8, "A3": 34.1, "A4": 0, "A5": -33.7, "A6": 0}

HEAD = [";Version:310", ";[Point&S]", ";[Point&E]", ";[Program&SV2]"]
TAIL = [";[Program&E]"]


class Prog:
    """組裝 .hrb;自動編號點位、管理計時器與對照表。"""

    def __init__(self, title: str, note: str = "") -> None:
        self.lines: list[str] = list(HEAD)
        self.idx = 0
        self.timers: list[tuple[int, str, int]] = []   # (編號, 說明, 重複次數)
        self.title = title
        self.lines.append(f"; ===== {title} =====")
        for ln in note.splitlines():
            if ln.strip():
                self.lines.append(f"; {ln.strip()}")

    # ---- 基本元素 ----
    def comment(self, text: str) -> None:
        self.lines += ["", f"; --- {text} ---"]

    def move(self, pose: dict, cmd: str, label: str = "") -> None:
        self.idx += 1
        body = ",".join(f"{k} {v}" for k, v in pose.items())
        self.lines.append("")
        if label:
            self.lines.append(f"; <Pose {self.idx}> {label}")
        self.lines.append(f"E6AXIS P{self.idx}={{{body}}}")
        self.lines.append(cmd.replace("P#", f"P{self.idx}"))

    def home(self, pose: dict = POSE_A) -> None:
        self.comment("歸位(慢速,不計時)")
        self.move(pose, "PTP P# FINE=2 Vel=15% Acc=30% TOOL[0] BASE[0]", "起始點")

    # ---- 計時區塊 ----
    def timed(self, n: int, desc: str, moves: list[tuple[dict, str]], repeat: int = 1) -> None:
        """把 moves 包進 $T[n] 計時區塊,重複 repeat 次(取總和再自行平均)。"""
        self.timers.append((n, desc, repeat))
        self.lines += [
            "",
            f"; ########## $T[{n}] {desc}"
            + (f"(重複 {repeat} 次,結果請除以 {repeat})" if repeat > 1 else "")
            + " ##########",
            f"$T[{n}] = 0",
            "WAIT SEC 0",
            f"$T_STOP[{n}] = FALSE",
        ]
        for _ in range(repeat):
            for pose, cmd in moves:
                self.move(pose, cmd)
        self.lines += ["", "WAIT SEC 0", f"$T_STOP[{n}] = TRUE"]

    # ---- 輸出 ----
    def text(self) -> str:
        table = ["", "; ===== Timer 對照表(執行後於 Timer 分頁抄錄)====="]
        for n, desc, rep in self.timers:
            suffix = f"   ÷{rep}" if rep > 1 else ""
            table.append(f";   $T[{n}] = {desc}{suffix}")
        return "\n".join(self.lines + table + [""] + TAIL) + "\n"

    def summary(self) -> list[tuple[int, str, int]]:
        return self.timers


# ---------------------------------------------------------------- 測試 1
def test_acc_effect() -> Prog:
    p = Prog(
        "TEST 1 | PTP_TIME 模式下 Acc 是否有作用",
        """相同兩點、相同 TIME=3000ms,只改 Acc:100 / 60 / 30 / 10。
        每組來回各 3 次(6 段,理論總長 18000ms)→ 55ms 精度誤差被稀釋。
        判讀:
          (a) 四個 Timer 若都約 18000ms → Acc 不改變總時間(預期)
          (b) 但動作的「猛烈程度」應不同 → 這才是 Acc 的表現力,需目視/錄影
          (c) 若 Acc=10 明顯超過 18000ms → 低加速度無法達成指定時間,
              代表 Acc 會限制 TIME 的可行域,程式須把 Acc 納入 T_min 計算""",
    )
    p.home()
    for n, acc in enumerate((100, 60, 30, 10), start=1):
        p.timed(
            n, f"Acc={acc}% TIME=3000 來回",
            [(POSE_B, f"PTP_TIME P# FINE=2 TIME=3000 msec Acc={acc}% TOOL[0] BASE[0]"),
             (POSE_A, f"PTP_TIME P# FINE=2 TIME=3000 msec Acc={acc}% TOOL[0] BASE[0]")],
            repeat=3,
        )
    return p


# ---------------------------------------------------------------- 測試 2
def test_acc_limit() -> Prog:
    p = Prog(
        "TEST 2 | 最短時間探測(T_min 與 Acc 的關係)",
        """同一大位移,TIME 逐步縮短;Acc=100% 與 30% 各一輪。
        TIME 越短重複次數越多,讓每組總時間都在 3 秒以上。
        判讀:
          (a) 實際 ÷ (重複次數×2段) 若 > 指令 TIME → 控制器自行延長 = 已達極限
          (b) 找出開始偏離的臨界 TIME → 那就是該位移的 T_min
          (c) Acc=30 的臨界點若比 Acc=100 更早出現 → 加速度確實參與限制
          (d) 出現警報請記下代碼並跳過該輪剩餘項目
        ★ 這也是判斷「離線模擬器可不可信」的關鍵測試:
          若 300ms 那組回報恰好 300ms/段,表示模擬器不模擬動力學限制,
          test1/test2 的數據必須改上實機重跑。""",
    )
    p.home()
    n = 1
    for acc in (100, 30):
        for ms, rep in ((3000, 1), (1500, 2), (800, 3), (500, 4), (300, 6)):
            p.timed(
                n, f"Acc={acc}% TIME={ms}ms",
                [(POSE_B, f"PTP_TIME P# FINE=2 TIME={ms} msec Acc={acc}% TOOL[0] BASE[0]"),
                 (POSE_A, f"PTP_TIME P# FINE=2 TIME={ms} msec Acc={acc}% TOOL[0] BASE[0]")],
                repeat=rep,
            )
            n += 1
    return p


# ---------------------------------------------------------------- 測試 3(修正版)
def test_vel_inherit() -> Prog:
    p = Prog(
        "TEST 3B | 參數繼承:PTP_TIME 會不會受前一行 Vel 影響",
        """修正說明:前一版在 PTP_TIME 行加 Vel=100%,實測為語法錯誤
        —— PTP_TIME 不接受 Vel 參數,該輪已移除。
        另一項修正:TIME 從 2000 改為 3000ms。實測顯示此位移在 2000ms
        會被時間下限夾住(約 1975ms/段),差異會被掩蓋;3000ms 才在可行域內。
        四輪比較(幾何相同,各來回 3 次 = 6 段):
          $T[1] 前導 Vel=10%  → PTP_TIME(理論 18000ms)
          $T[2] 前導 Vel=100% → PTP_TIME(理論 18000ms)
          $T[3] 前導 Vel=10%  → 純 PTP Vel 省略(對照組:確認繼承機制存在)
          $T[4] 前導 Vel=100% → 純 PTP Vel 省略(對照組)
        判讀:
          $T[1] ≈ $T[2] → PTP_TIME 不受繼承影響,codegen 維持現狀
          $T[1] > $T[2] → 會受影響,codegen 需在前一行控制 Vel 狀態
          $T[3] > $T[4] → 確認繼承機制確實存在(純 PTP 一定會受影響)""",
    )
    p.home()

    p.comment("前導行:Vel=10%")
    p.move(POSE_A, "PTP P# FINE=2 Vel=10% Acc=100% TOOL[0] BASE[0]", "前導(慢)")
    p.timed(
        1, "前導Vel=10% → PTP_TIME TIME=3000",
        [(POSE_B, "PTP_TIME P# FINE=2 TIME=3000 msec Acc=100% TOOL[0] BASE[0]"),
         (POSE_A, "PTP_TIME P# FINE=2 TIME=3000 msec Acc=100% TOOL[0] BASE[0]")],
        repeat=3,
    )

    p.comment("前導行:Vel=100%")
    p.move(POSE_A, "PTP P# FINE=2 Vel=100% Acc=100% TOOL[0] BASE[0]", "前導(快)")
    p.timed(
        2, "前導Vel=100% → PTP_TIME TIME=3000",
        [(POSE_B, "PTP_TIME P# FINE=2 TIME=3000 msec Acc=100% TOOL[0] BASE[0]"),
         (POSE_A, "PTP_TIME P# FINE=2 TIME=3000 msec Acc=100% TOOL[0] BASE[0]")],
        repeat=3,
    )

    p.comment("對照組:前導 Vel=10% → 純 PTP 省略 Vel")
    p.move(POSE_A, "PTP P# FINE=2 Vel=10% Acc=100% TOOL[0] BASE[0]", "前導(慢)")
    p.timed(
        3, "前導Vel=10% → PTP 省略 Vel(對照)",
        [(POSE_B, "PTP P# FINE=2 Acc=100% TOOL[0] BASE[0]"),
         (POSE_A, "PTP P# FINE=2 Acc=100% TOOL[0] BASE[0]")],
        repeat=3,
    )

    p.comment("對照組:前導 Vel=100% → 純 PTP 省略 Vel")
    p.move(POSE_A, "PTP P# FINE=2 Vel=100% Acc=100% TOOL[0] BASE[0]", "前導(快)")
    p.timed(
        4, "前導Vel=100% → PTP 省略 Vel(對照)",
        [(POSE_B, "PTP P# FINE=2 Acc=100% TOOL[0] BASE[0]"),
         (POSE_A, "PTP P# FINE=2 Acc=100% TOOL[0] BASE[0]")],
        repeat=3,
    )
    return p


# ---------------------------------------------------------------- 測試 6(新增)
def test_cont_isolate() -> Prog:
    p = Prog(
        "TEST 6 | 隔離 CONT 的效果(修正 TEST 5 的設計缺陷)",
        """TEST 5 的問題:拿 PTP_TIME+FINE(時間驅動)去比 PTP+CONT+Vel(速度驅動),
        同時改了兩個變因,量到的 2.4 倍差異其實只是 Vel=30% 比較慢,
        跟 CONT 無關。
        本測試把 Vel 固定為 30%,只變動軌跡形式 —— 差異才真正來自 CONT。
        五輪,四點循環各 3 圈(12 段):
          $T[1] PTP FINE=2 Vel=30%(完全到位)
          $T[2] PTP FINE=1 Vel=30%(基準)
          $T[3] PTP FINE=0 Vel=30%(有預讀)
          $T[4] PTP CONT   Vel=30%
          $T[5] PTP CONT=100% Vel=30%
        判讀:
          ($T[2] − $T[4]) ÷ 12 = 每個轉角因圓滑而省下的時間
              → 這才是錨點補償真正要扣的量
          $T[4] vs $T[5] 若仍相同 → 圓滑百分比對時間無影響(需目視確認路徑差異)
          $T[3] vs $T[2] 應差約 62ms/點(前次測得的預讀效益)
        ★ 目視重點:CONT 那兩輪是否真的不停頓、轉角是否走內側捷徑。""",
    )
    p.home()
    seq = [POSE_B, POSE_C, POSE_D, POSE_A]
    modes = [(1, "FINE=2"), (2, "FINE=1"), (3, "FINE=0"), (4, "CONT"), (5, "CONT=100%")]
    for n, mode in modes:
        p.timed(
            n, f"{mode} Vel=30% ×12段",
            [(pose, f"PTP P# {mode} Vel=30% Acc=100% TOOL[0] BASE[0]") for pose in seq],
            repeat=3,
        )
    return p


# ---------------------------------------------------------------- 測試 4
def test_fine_levels() -> Prog:
    p = Prog(
        "TEST 4 | FINE 三個等級的停頓差異",
        """同一組四點循環,分別用 FINE=2 / 1 / 0,各跑 3 圈(12 段,理論 14400ms)。
        判讀:
          每點額外停頓 = ($T[x] − 最小的那個 Timer) ÷ 12
        FINE=2 應最長(到位檢查)、FINE=0 最短(有預讀)。
        這個差值決定 Pop 頓點的「定格感」有多強,填進質感分級參數。""",
    )
    p.home()
    seq = [POSE_B, POSE_C, POSE_D, POSE_A]
    for n, fine in enumerate((2, 1, 0), start=1):
        p.timed(
            n, f"FINE={fine} 四段×3圈",
            [(pose, f"PTP_TIME P# FINE={fine} TIME=1200 msec Acc=100% TOOL[0] BASE[0]")
             for pose in seq],
            repeat=3,
        )
    return p


# ---------------------------------------------------------------- 測試 5
def test_cont_track() -> Prog:
    p = Prog(
        "TEST 5 | 流暢軌(PTP + CONT + Vel)與時序漂移",
        """雙軌設計的核心驗證。四點循環各 3 圈(12 段):
          $T[1] PTP_TIME + FINE=1(基準,理論 14400ms)
          $T[2] PTP + CONT + Vel=30%
          $T[3] PTP + CONT=50% + Vel=30%
          $T[4] PTP + CONT=100% + Vel=30%
        判讀:
          (a) $T[1] 應約 14400ms(1200×12)
          (b) $T[2..4] 與 $T[1] 的差 = CONT「偷掉」的時間,
              除以 12 就是每個轉角的平均縮減 → 錨點補償要扣的量
          (c) CONT 百分比越高偷得越多 → 可畫出「平滑度 vs 時間損失」曲線
          (d) 目視確認 CONT 輪是否真的不停頓、轉角被削圓""",
    )
    p.home()
    seq = [POSE_B, POSE_C, POSE_D, POSE_A]

    p.timed(
        1, "基準 PTP_TIME FINE=1 (1200ms×12段)",
        [(pose, "PTP_TIME P# FINE=1 TIME=1200 msec Acc=100% TOOL[0] BASE[0]") for pose in seq],
        repeat=3,
    )
    for n, cont in enumerate(("CONT", "CONT=50%", "CONT=100%"), start=2):
        p.timed(
            n, f"{cont} Vel=30% ×12段",
            [(pose, f"PTP P# {cont} Vel=30% Acc=100% TOOL[0] BASE[0]") for pose in seq],
            repeat=3,
        )
    return p




# ---------------------------------------------------------------- 測試 7(診斷)
def test_speed_source() -> Prog:
    """診斷「實測只有規格 40%」的來源。"""
    p = Prog(
        "TEST 7 | 速度落差診斷:規格 192°/s vs 實測 75.9°/s",
        """手冊 2.8 節已排除運行方式:AUT 用「程式設計速度」,不像 T1 有 250mm/s 上限。
        因此 40% 落差來自其他原因,本測試用兩個對照組區分:

        對照 A(各軸速度比例)$T[1]-$T[5]:
          每軸單獨大幅轉動,Vel=100%,算出各軸實際速度。
          若各軸都是規格的同一比例(例如都 40%)→ 全域覆寫或機型設定不符
          若比例各不相同 → 各軸機械資料個別設定
          規格參考:J1 192 / J2 206 / J3 219 / J4 450 / J5 450 / J6 720 (deg/s)

        對照 B(手臂伸展程度)$T[6]-$T[7]:
          同樣的 J1 轉動幅度,分別在「收攏」與「伸展」姿態下執行。
          若伸展時明顯較慢 → 笛卡爾(末端 TCP)速度限制在生效
          若兩者相同     → 純關節速度限制,與臂展無關

        判讀後對策:
          機型設定不符 → 改模擬器機型為 RA610-GC 1476
          全域覆寫     → 檢查 $OV_PRO 與運行方式速度設定
          各軸設定     → 查控制器機械資料
          TCP 限制     → 編舞時避免大幅伸展下的快速迴轉""",
    )
    p.home()

    # --- 對照 A:各軸單獨轉動(其餘軸維持安全基準姿態)---
    base = dict(POSE_A)
    singles = [
        (1, "J1", "A1", -60.0, 60.0),
        (2, "J2", "A2", -80.0, -20.0),
        (3, "J3", "A3", -60.0, 30.0),
        (4, "J4", "A4", -90.0, 90.0),
        (5, "J6", "A6", -90.0, 90.0),
    ]
    for n, label, axis, lo, hi in singles:
        a = dict(base); a[axis] = lo
        b = dict(base); b[axis] = hi
        p.comment(f"{label} 單軸 {hi - lo:.0f} 度,Vel=100%")
        p.move(a, "PTP P# FINE=2 Vel=30% Acc=100% TOOL[0] BASE[0]", f"{label} 就位")
        p.timed(
            n, f"{label} 單軸 {hi - lo:.0f}deg x2 Vel=100%",
            [(b, "PTP P# FINE=2 Vel=100% Acc=100% TOOL[0] BASE[0]"),
             (a, "PTP P# FINE=2 Vel=100% Acc=100% TOOL[0] BASE[0]")],
            repeat=3,
        )

    # --- 對照 B:相同 J1 幅度、不同伸展程度 ---
    for n, label, j2, j3 in ((6, "收攏姿態", -47.1, -75.2), (7, "伸展姿態", -8.6, 41.0)):
        a = {"A1": -60.0, "A2": j2, "A3": j3, "A4": 0, "A5": -15.0, "A6": 0}
        b = dict(a); b["A1"] = 60.0
        p.comment(f"{label}(J2={j2}, J3={j3})下的 J1 120 度轉動")
        p.move(a, "PTP P# FINE=2 Vel=30% Acc=100% TOOL[0] BASE[0]", f"{label} 就位")
        p.timed(
            n, f"J1 120deg @ {label} Vel=100%",
            [(b, "PTP P# FINE=2 Vel=100% Acc=100% TOOL[0] BASE[0]"),
             (a, "PTP P# FINE=2 Vel=100% Acc=100% TOOL[0] BASE[0]")],
            repeat=3,
        )
    return p




# ---------------------------------------------------------------- 測試 8(Vel 超頻)
def test_vel_overdrive() -> Prog:
    p = Prog(
        "TEST 8 | Vel 超過 100% 是否真的更快(100% = 額定而非最大?)",
        """發現:PTP 的 Vel 語法可接受 >100%(至 200%)。手冊寫 1~100,
        但若 100% 只是「額定速度」,200% 才逼近真實上限,
        則正好解釋實測速度只有規格四成的謎。語法不報錯不代表有效
        (可能內部夾回 100),本測試直接量。
        四輪,J1 單軸 120 度來回 x3(J1 為速度受限段,靈敏度最高):
          $T[1] Vel=50%   $T[2] Vel=100%   $T[3] Vel=150%   $T[4] Vel=200%
        預測值(每段,用現有模型 v100=75.9 deg/s):
          Vel=50  → 3.36s    Vel=100 → 1.90s(已驗證)
          若線性有效:Vel=150 → 1.49s   Vel=200 → 1.34s
          若夾回 100:Vel=150 ≈ Vel=200 ≈ 1.90s
        判讀:$T[3]/$T[4] 明顯小於 $T[2] → 超頻有效,速度模型全面改寫;
              三者相同 → 夾回,維持現狀。
        ★ 若有效,連帶測 Acc 是否也收 >100(另行小測)。""",
    )
    p.home()
    a = dict(POSE_A); a["A1"] = -60.0
    b = dict(a); b["A1"] = 60.0
    p.move(a, "PTP P# FINE=2 Vel=30% Acc=100% TOOL[0] BASE[0]", "就位")
    for n, vel in enumerate((50, 100, 150, 200), start=1):
        p.timed(
            n, f"J1 120deg Vel={vel}%",
            [(b, f"PTP P# FINE=2 Vel={vel}% Acc=100% TOOL[0] BASE[0]"),
             (a, f"PTP P# FINE=2 Vel={vel}% Acc=100% TOOL[0] BASE[0]")],
            repeat=3,
        )
    return p




# ---------------------------------------------------------------- 測試 9(上限探測)
def test_ceiling() -> Prog:
    p = Prog(
        "TEST 9 | Vel=250 是否更快 + PTP_TIME 的內部速度上限",
        """兩個問題一次量(全部 J1 單軸 120 度來回 x3,同 test8 幾何):

        A. Vel 天花板:$T[1] Vel=200(對照,已知 964ms/段)、$T[2] Vel=250
           預測:若線性到 250 → 810ms/段;若內部頂在 200 → 964ms/段
           (Vel=300 探針在另一支 test9b,若語法錯誤只死那支)

        B. PTP_TIME 是否吃超頻:$T[3..6] 用 PTP_TIME 指令 TIME 遞減
           此動作額定速度(=Vel100)的物理下限約 1.90s/段:
             $T[3] TIME=2000 → 兩種假說都應 ≈2.0s(自我校驗)
             $T[4] TIME=1400 → 額定鎖:≈1.90s|吃超頻:≈1.40s
             $T[5] TIME=1000 → 額定鎖:≈1.90s|吃超頻:≈1.00s
             $T[6] TIME=600  → 額定鎖:≈1.90s|吃超頻:≈0.96s(頂 200% 極限)
           旁證:test2 的 T_min 1975ms 恰為額定運動學時間,暗示「額定鎖」。

        若證實額定鎖 → 重拍錨點是全系統最慢的軌,需要混合軌補救
        (極快 hit 改 PTP+FINE+Vel 超頻,時間誤差由下一錨點吸收)。""",
    )
    p.home()
    a = dict(POSE_A); a["A1"] = -60.0
    b = dict(a); b["A1"] = 60.0
    p.move(a, "PTP P# FINE=2 Vel=30% Acc=100% TOOL[0] BASE[0]", "就位")
    for n, vel in ((1, 200), (2, 250)):
        p.timed(n, f"J1 120deg Vel={vel}%",
                [(b, f"PTP P# FINE=2 Vel={vel}% Acc=100% TOOL[0] BASE[0]"),
                 (a, f"PTP P# FINE=2 Vel={vel}% Acc=100% TOOL[0] BASE[0]")], repeat=3)
    for n, ms in ((3, 2000), (4, 1400), (5, 1000), (6, 600)):
        p.timed(n, f"PTP_TIME TIME={ms}ms",
                [(b, f"PTP_TIME P# FINE=2 TIME={ms} msec Acc=100% TOOL[0] BASE[0]"),
                 (a, f"PTP_TIME P# FINE=2 TIME={ms} msec Acc=100% TOOL[0] BASE[0]")], repeat=3)
    return p


def test_ceiling_probe() -> Prog:
    p = Prog(
        "TEST 9B | Vel=300 語法探針(獨立檔:若報語法錯誤只影響本檔)",
        "只有一組。載入失敗=300 超出輸入上限;能跑則量 $T[1]。",
    )
    p.home()
    a = dict(POSE_A); a["A1"] = -60.0
    b = dict(a); b["A1"] = 60.0
    p.move(a, "PTP P# FINE=2 Vel=30% Acc=100% TOOL[0] BASE[0]", "就位")
    p.timed(1, "J1 120deg Vel=300%",
            [(b, "PTP P# FINE=2 Vel=300% Acc=100% TOOL[0] BASE[0]"),
             (a, "PTP P# FINE=2 Vel=300% Acc=100% TOOL[0] BASE[0]")], repeat=3)
    return p


TESTS = {
    "test1_acc_effect": test_acc_effect,
    "test2_acc_limit": test_acc_limit,
    "test3_vel_inherit": test_vel_inherit,
    "test4_fine_levels": test_fine_levels,
    "test5_cont_track": test_cont_track,
    "test6_cont_isolate": test_cont_isolate,
    "test7_speed_source": test_speed_source,
    "test8_vel_overdrive": test_vel_overdrive,
    "test9_ceiling": test_ceiling,
    "test9b_vel300_probe": test_ceiling_probe,
    "test10_ptptime_ceiling": test_ptptime_ceiling,
}


def measurement_csv(progs: dict[str, Prog]) -> str:
    rows = ["test,timer,item,repeat,measured_ms,per_segment_ms,alarm,note"]
    for name, p in progs.items():
        t = name.split("_")[0].replace("test", "")
        for n, desc, rep in p.summary():
            rows.append(f"{t},$T[{n}],{desc},{rep},,,,")
    return "\n".join(rows) + "\n"


def main() -> int:
    ap = argparse.ArgumentParser(description="產生驗證測試程式(內建計時器)")
    ap.add_argument("-o", "--out", default="tests_hrb")
    args = ap.parse_args()

    d = Path(args.out)
    d.mkdir(parents=True, exist_ok=True)
    progs = {}
    for name, fn in TESTS.items():
        p = fn()
        progs[name] = p
        (d / f"{name}.hrb").write_text(p.text(), encoding="utf-8")
        print(f"✓ {d / (name + '.hrb')}  ({len(p.summary())} 個計時器)")
    (d / "measurements.csv").write_text(measurement_csv(progs), encoding="utf-8")
    print(f"✓ {d / 'measurements.csv'}(填 measured_ms 欄)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
